package dao;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.EmployeeCertification;
import entity.CertificationEntity;
import entity.EmployeeCertificationEntity;
import entity.EmployeeEntity;
import entity.PrimaryKey;

public class EmployeeCertificationDAO {

	public void addEmployeeCertification(EmployeeCertification employeeCertification) throws Exception {
		
		EmployeeCertificationEntity employeeCertificationEntity = null;
		
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session=null;
		try {
			session = sessionFactory.openSession();
			
			EmployeeEntity employeeEntity=(EmployeeEntity) session.get(EmployeeEntity.class, employeeCertification.getEmpId());
			CertificationEntity certificationEntity=(CertificationEntity) session.get(CertificationEntity.class, employeeCertification.getCertificationCode().toUpperCase());
			
			if(employeeEntity!=null && certificationEntity!=null){
				PrimaryKey primaryKey = new PrimaryKey();
				primaryKey.setCertificationCode(employeeCertification.getCertificationCode());
				primaryKey.setEmpId(employeeCertification.getEmpId());
			
				employeeCertificationEntity = new EmployeeCertificationEntity();
				employeeCertificationEntity.setMarks(employeeCertification.getMarks());
				employeeCertificationEntity.setPrimaryKey(primaryKey);
			
				session.getTransaction().begin();
				session.persist(employeeCertificationEntity);
				session.getTransaction().commit();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
	}

	/**
	 * Fetches the certification details for the accepted employeeId and
	 * certificationCode from the database
	 * 
	 * @param emloyeeId
	 * @param certificationCode
	 * @return EmployeeCertification
	 * @throws Exception
	 *             if there is a technical error
	 */
	public EmployeeCertification getEmployeeCertificationDetails(Integer empId,String certificationCode) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		EmployeeCertification employeeCertification = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			
			EmployeeEntity employeeEntity=(EmployeeEntity) session.get(EmployeeEntity.class, empId);
			CertificationEntity certificationEntity=(CertificationEntity) session.get(CertificationEntity.class, certificationCode);
			PrimaryKey primaryKey=null;
			if(employeeEntity!=null && certificationEntity!=null){
				primaryKey = new PrimaryKey();
				primaryKey.setCertificationCode(certificationCode.toUpperCase());
				primaryKey.setEmpId(empId);
			}
			
			
			EmployeeCertificationEntity empCertEntity = (EmployeeCertificationEntity) session.get(EmployeeCertificationEntity.class, primaryKey);
			if (empCertEntity != null) {
				employeeCertification = new EmployeeCertification();
				employeeCertification.setMarks(empCertEntity.getMarks());
				
				employeeCertification.setEmpId(empId);
				employeeCertification.setCertificationCode(certificationCode);
				employeeCertification.setEmployeeName(employeeEntity.getName());
				employeeCertification.setCertificationName(certificationEntity.getCertificationName());
				employeeCertification.setCertificationType(certificationEntity.getCertificationType());
			}

		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return employeeCertification;
	}
}
