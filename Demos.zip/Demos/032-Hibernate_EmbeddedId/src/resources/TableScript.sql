DROP TABLE Cpkey_Employee CASCADE CONSTRAINTS;
DROP TABLE Cpkey_Certification CASCADE CONSTRAINTS;
DROP TABLE Cpkey_EmployeeCertification CASCADE CONSTRAINTS;

CREATE TABLE Cpkey_Employee(EmpId Number(7) CONSTRAINT CPK_EmpPK PRIMARY KEY,
Name varchar2(25) CONSTRAINT CPK_EName_Nnull NOT NULL);

CREATE TABLE Cpkey_Certification(CertificationCode Varchar2(10) 
CONSTRAINT CPK_CertPK PRIMARY KEY,
CertificationName varchar2(80) CONSTRAINT CPK_CName_Nnull NOT NULL 
CONSTRAINT CPK_Cert_Unique UNIQUE,
CertificationType varchar2(20) CONSTRAINT CPK_CType_Nnull NOT NULL);

CREATE TABLE Cpkey_EmployeeCertification(CertificationCode Varchar2(10)
CONSTRAINT CPK_ECCode_Fkey REFERENCES Cpkey_Certification(CertificationCode),
EmpId Number(7)  
CONSTRAINT CPK_EIdFkey REFERENCES Cpkey_Employee(EmpId),  
Marks number(3) CONSTRAINT CPK_Marks_Nnull NOT NULL,
CONSTRAINT CP_ECert_Check CHECK (Marks BETWEEN 1 and 100),
CONSTRAINT Cpkey_ECertPK PRIMARY KEY(CertificationCode,EmpId));

INSERT INTO Cpkey_Employee VALUES(1001,'Scott');
INSERT INTO Cpkey_Employee VALUES(1002,'Jack');
INSERT INTO Cpkey_Employee VALUES(1003,'Ram');
INSERT INTO Cpkey_Employee VALUES(1004,'Sita');



INSERT INTO Cpkey_Certification VALUES('JAVA-101','Infy Certified Java Programmer','Internal-Technical');
INSERT INTO Cpkey_Certification VALUES('MS-101','Infy Certified C Sharp Programmer','Internal-Technical');
INSERT INTO Cpkey_Certification VALUES('1Z0-804','Oracle Certified Professional, Java SE 7 Programmer','External-Technical');
INSERT INTO Cpkey_Certification VALUES('1Z0-899','Oracle Certified Expert, Java EE 6 Web Component Developer','External-Technical');


INSERT INTO Cpkey_EmployeeCertification VALUES('JAVA-101',1001,75);
INSERT INTO Cpkey_EmployeeCertification VALUES('1Z0-804',1002,80);
INSERT INTO Cpkey_EmployeeCertification VALUES('1Z0-804',1001,94);




SELECT * FROM Cpkey_Employee;
SELECT * FROM Cpkey_Certification;
SELECT * FROM Cpkey_EmployeeCertification;
