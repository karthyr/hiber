//Import the necessary packages
package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import resources.AppConfig;

public class ScrollableDemo {

	public static void main(String[] args) {
		try {
			new ScrollableDemo().getCustomerDetails();
		} catch (Exception e) {
			System.err.println("ERROR: "+e.getMessage());
		}
	}
	
	public void getCustomerDetails() throws Exception {

		// Fetching the database credentials from the configuration.properties
		String DBConnectionURL = AppConfig.PROPERTIES.getProperty("DBConnectionURL");
		String DBUserName = AppConfig.PROPERTIES.getProperty("DBUserName");
		String DBPassword = AppConfig.PROPERTIES.getProperty("DBPassword");
		// Loading a database driver : Optional
		String sql="select * from customer";
		try (
		// Creating JDBC connection
		Connection connection = DriverManager.getConnection(DBConnectionURL,DBUserName, DBPassword);
		// Creating an insensitive scrollable resultset
		PreparedStatement pStatement = connection.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);) {
			
			// Executing the SQL query which returns a result set as obtained in case of SELECT statement
			ResultSet scrollableResultSet = pStatement.executeQuery();

			// To get the initial cursor position
			System.out.println("Initial cursor position : "+ scrollableResultSet.getRow());

			// Moving the cursor forward
			scrollableResultSet.next();
			System.out.println("Current cursor position after moving cursor one step forward: "+ scrollableResultSet.getRow());
			System.out.println("------------------------------");
			System.out.println("Customer Id : "+ scrollableResultSet.getInt("custId"));
			System.out.println("Customer Name : "+ scrollableResultSet.getString("customerName"));
			System.out.println("Email Id : "+scrollableResultSet.getString("emailId"));
			System.out.println("------------------------------");
			
			// Moving the cursor to the last row of scrollableResultset
			scrollableResultSet.last();
			System.out.println("Current cursor position after moving cursor to the last postion: "+ scrollableResultSet.getRow());
			System.out.println("------------------------------");
			System.out.println("Customer Id : "+ scrollableResultSet.getInt("custId"));
			System.out.println("Customer Name : "+ scrollableResultSet.getString("customerName"));
			System.out.println("Email Id : "+scrollableResultSet.getString("emailId"));
			System.out.println("------------------------------");
			
			// Moving the cursor to past last row of scrollableResultset ie,
			// before first row
			scrollableResultSet.afterLast();
			System.out.println("Current cursor position after executing the afterLast() method : "
							+ scrollableResultSet.getRow());
			
			// Moving the cursor to a specific row ( try with negative positions )
			scrollableResultSet.absolute(2);
			System.out
					.println("Current cursor position after executing the absolute method : "
							+ scrollableResultSet.getRow());
			
			// Moving the cursor relative to the current position ( try with negative positions )
			scrollableResultSet.relative(2);
			System.out.println("Current cursor position after executing the relative : "
							+ scrollableResultSet.getRow());
			
		} catch (SQLException exception) {
			throw new Exception("DAO.TECHNICAL_ERROR"); 
		} catch (Exception exception) {
			throw exception;
		} 

	}

}
