
drop table Customer cascade constraints;

create table Customer (
custId number(4) primary key,
customerName varchar2(10),
emailId varchar2(25),
phoneNo number (10));


insert into Customer values(1001,'Jack','Jack@infy.com',1234567890);
insert into Customer values(1002,'Justin','Justin@infy.com',6678599344);
insert into Customer values(1003,'James','James@infy.com',2341548796);

select * from Customer;
