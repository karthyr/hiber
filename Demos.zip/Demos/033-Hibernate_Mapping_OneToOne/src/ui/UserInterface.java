package ui;

import resources.AppConfig;
import resources.HibernateUtility;
import bean.Asset;
import bean.Employee;
import dao.AssetAllocationDAO;

public class UserInterface {

	public static void getAssetDetails(String assetId) {
		try {
			AssetAllocationDAO dao = new AssetAllocationDAO();
			Asset asset = dao.getAssetDetails(assetId);
			System.out.println("----------------Asset Details----------------");
			System.out.println("Asset Id: " + asset.getAssetId());
			System.out.println("Asset Type: " + asset.getAssetType());
			System.out.println("Manufacturer: " + asset.getManufacturer());
			System.out.println("---------------------------------------------");
		
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	public static void getEmployeeDetails(Integer empId) {
		try {
			AssetAllocationDAO dao = new AssetAllocationDAO();
			Employee employee = dao.getEmployeeDetails(empId);
			System.out.println("---------------Employee Details----------------");
			System.out.println("Employee Id: "+employee.getEmpId());
			System.out.println("Employee Name:"+employee.getName());
			System.out.println();
			System.out.println("---------------Asset Details-------------------");
			System.out.println("Asset Id: " + employee.getAsset().getAssetId());
			System.out.println("Asset Type: " + employee.getAsset().getAssetType());
			System.out.println("Manufacturer: " + employee.getAsset().getManufacturer());
			System.out.println("-----------------------------------------------");
		
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	public static void addNewAsset(String assetId, String assetType,String manufacturer) {

		try {
			Asset asset = new Asset();
			asset.setAssetId(assetId);
			asset.setAssetType(assetType);
			asset.setManufacturer(manufacturer);

			AssetAllocationDAO dao = new AssetAllocationDAO();
			dao.addNewAsset(asset);
			String message = AppConfig.PROPERTIES.getProperty("UserInterface.NEW_ASSET_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	public static void addNewEmployee(Integer empId,
			String name) {

		try {
			Employee employee=new Employee();
			employee.setEmpId(empId);
			employee.setName(name);
			AssetAllocationDAO dao = new AssetAllocationDAO();
			dao.addNewEmployee(employee);
			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.NEW_EMPLOYEE_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	public static void allocateAsset(Integer empId, String assetId) {
		try {
			AssetAllocationDAO dao = new AssetAllocationDAO();
			dao.allocateAsset(empId, assetId);
			String message = AppConfig.PROPERTIES.getProperty("UserInterface.ASSET_ALLOCATED_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deallocateAsset(Integer empId) {
		try {
			AssetAllocationDAO dao = new AssetAllocationDAO();
			dao.deallocateAsset(empId);
			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.ASSET_DEALLOCATED_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	public static void deleteEmployeeOnly(Integer empId) {
		try {
			AssetAllocationDAO dao = new AssetAllocationDAO();
			dao.deleteEmployeeOnly(empId);
			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.EMPLOYEE_DELETED_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteAssetOnly(String assetId) {
		try {
			AssetAllocationDAO dao = new AssetAllocationDAO();
			dao.deleteAssetOnly(assetId);
			String message = AppConfig.PROPERTIES.getProperty("UserInterface.ASSET_DELETED_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteAssetandEmployee(Integer empId) {
		try {
			AssetAllocationDAO dao = new AssetAllocationDAO();
			dao.deleteAssetandEmployee(empId);
			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.ASSET_EMPLOYEE_DELETED_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void main(String args[]) {
		 try{
			 	//getAssetDetails("Infy003");
			 	//getEmployeeDetails(1003);
				//addNewAsset("Infy002","Laptop","HP");
				//addNewEmployee(1008,"Ram");
				//allocateAsset(1008,"Infy002");
				//deallocateAsset(1002);
			 	//deleteAssetOnly("Infy002");
				//deleteEmployeeOnly(1008);
				//deleteAssetandEmployee(1004);
		 }finally{
			 HibernateUtility.closeSessionFactory();
		 }
		
		 
	}
}
