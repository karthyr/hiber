package dao;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Asset;
import bean.Employee;
import entity.AssetEntity;
import entity.EmployeeEntity;

public class AssetAllocationDAO {
	/**
	 * Fetches the employee and the corresponding asset details from the
	 * database
	 * 
	 * @param empId
	 * @return Employee
	 * @throws Exception
	 *             if there is a technical error
	 */
	public Employee getEmployeeDetails(Integer empId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;

		Employee employee = null;

		try {
			session = sessionFactory.openSession();

			EmployeeEntity employeeEntity = (EmployeeEntity) session.get(
					EmployeeEntity.class, empId);

			if (employeeEntity != null) {
				employee = new Employee();
				employee.setEmpId(employeeEntity.getEmpId());
				employee.setName(employeeEntity.getName());

				Asset asset = new Asset();
				asset.setAssetId(employeeEntity.getAsset().getAssetId());
				asset.setAssetType(employeeEntity.getAsset().getAssetType());
				asset.setManufacturer(employeeEntity.getAsset()
						.getManufacturer());

				employee.setAsset(asset);
			}

		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (session.isOpen()|| session!=null) {
				session.close();
			}

		}
		return employee;
	}

	/**
	 * Fetches the asset details from the database
	 * 
	 * 
	 * @param assetId
	 * @return Asset
	 * @throws Exception
	 *             if there is a technical error
	 */
	public Asset getAssetDetails(String assetId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Asset asset = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			AssetEntity assetEntity = (AssetEntity) session.get(
					AssetEntity.class, assetId);

			if (assetEntity != null) {
				asset = new Asset();
				asset.setAssetId(assetEntity.getAssetId());
				asset.setAssetType(assetEntity.getAssetType());
				asset.setManufacturer(assetEntity.getManufacturer());
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (session.isOpen()|| session!=null) {
				session.close();
			}
		}
		return asset;
	}

	/**
	 * Adds new employee to the database
	 * 
	 * @param employee
	 * @throws Exception
	 *             if there is a technical error
	 */
	public void addNewEmployee(Employee employee) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		EmployeeEntity employeeEntity = null;
		try {
			employeeEntity = new EmployeeEntity();
			employeeEntity.setEmpId(employee.getEmpId());
			employeeEntity.setName(employee.getName());

			// Setting the asset details to NULL
			employeeEntity.setAsset(null);
			session.getTransaction().begin();
			session.persist(employeeEntity);
			session.getTransaction().commit();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (session.isOpen()|| session!=null) {
				session.close();
			}

		}
	}

	/**
	 * Adds new asset to the database
	 * 
	 * @param Asset
	 * @throws Exception
	 *             if there is a technical error
	 */
	public void addNewAsset(Asset asset) throws Exception {

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();

			AssetEntity assetEntity = new AssetEntity();
			assetEntity.setAssetId(asset.getAssetId());
			assetEntity.setAssetType(asset.getAssetType());
			assetEntity.setManufacturer(asset.getManufacturer());

			session.getTransaction().begin();
			session.persist(assetEntity);
			session.getTransaction().commit();

		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (session.isOpen()|| session!=null) {
				session.close();
			}

		}
	}

	/**
	 * Allocates the existing asset to an existing employee
	 * 
	 * @param empId
	 * @param assetId
	 * @throws Exception
	 *             if there is a technical error
	 */
	public void allocateAsset(Integer empId, String assetId) throws Exception {

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();

			AssetEntity assetEntity = (AssetEntity) session.get(
					AssetEntity.class, assetId);
			EmployeeEntity employeeEntity = (EmployeeEntity) session.get(
					EmployeeEntity.class, empId);

			if (employeeEntity != null && assetEntity != null) {

				employeeEntity.setAsset(assetEntity);

				session.getTransaction().begin();
				//session.persist(employeeEntity);
				session.getTransaction().commit();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (session.isOpen()|| session!=null) {
				session.close();
			}

		}
	}

	/**
	 * Deallocates the asset
	 * 
	 * @param empId
	 * @throws Exception
	 *             if there is a technical error
	 */
	public void deallocateAsset(Integer empId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();

			EmployeeEntity employeeEntity = (EmployeeEntity) session.get(
					EmployeeEntity.class, empId);
			if (employeeEntity != null) {
				employeeEntity.setAsset(null);
			}

			session.getTransaction().begin();
			session.getTransaction().commit();

		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (session.isOpen()|| session!=null) {
				session.close();
			}

		}
	}

	/**
	 * Deletes ONLY the employee from the database without deleting the
	 * corresponding asset
	 * 
	 * @param assetId
	 * @throws Exception
	 *             if there is a technical error
	 */
	public void deleteEmployeeOnly(Integer empId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			EmployeeEntity employeeEntity = (EmployeeEntity) session.get(
					EmployeeEntity.class, empId);
			if (employeeEntity != null) {
				employeeEntity.setAsset(null);
				session.getTransaction().begin();
				session.delete(employeeEntity);
				session.getTransaction().commit();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (session.isOpen()|| session!=null) {
				session.close();
			}

		}
	}

	/**
	 * Deletes ONLY the asset from the database
	 * 
	 * @param assetId
	 * @throws Exception
	 *             if there is a technical error
	 */
	public void deleteAssetOnly(String assetId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();

			AssetEntity assetEntity = (AssetEntity) session.get(
					AssetEntity.class, assetId);

			session.getTransaction().begin();
			session.delete(assetEntity);
			session.getTransaction().commit();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (session.isOpen()|| session!=null) {
				session.close();
			}

		}
	}

	/**
	 * Removes both the Asset and the corresponding employee from the database
	 * table. This is only an example to understand the concept. In a real
	 * application, the employee will not be removed when an Asset is removed
	 * 
	 * @param empId
	 * @throws Exception
	 *             if there is a technical error
	 */
	public void deleteAssetandEmployee(Integer empId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		EmployeeEntity employeeEntity = null;
		Session session = sessionFactory.openSession();
		try {

			employeeEntity = (EmployeeEntity) session.get(EmployeeEntity.class,
					empId);

			if (employeeEntity != null) {
				session.getTransaction().begin();
				session.delete(employeeEntity);
				session.getTransaction().commit();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (session.isOpen()|| session!=null) {
				session.close();
			}

		}
	}

}
