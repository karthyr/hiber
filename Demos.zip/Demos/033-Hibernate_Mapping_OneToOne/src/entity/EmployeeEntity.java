package entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "OneToOne_employee")
public class EmployeeEntity {
	@Id
	private Integer empId;
	private String name;

	/*
	 * cascadeType.ALL means all the persistence operations done on the parent will
	 * be passed to the child.
	 */
	
	@OneToOne(cascade = CascadeType.ALL)
	/*
	 * Make unique=true so that AllocatedAssetId cannot be duplicated
	 */
	
	@JoinColumn(name = "AllocatedAssetId", unique = true)
	// Target Entity Reference
	private AssetEntity assetEntity;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AssetEntity getAsset() {
		return assetEntity;
	}

	public void setAsset(AssetEntity assetEntity) {
		this.assetEntity = assetEntity;
	}

}
