DROP TABLE OneToOne_Employee CASCADE CONSTRAINTS;
DROP TABLE OnetoOne_Asset CASCADE CONSTRAINTS;

CREATE TABLE OnetoOne_Asset(
AssetId varchar2(10) CONSTRAINT OO_AssetPK PRIMARY KEY,
AssetType varchar2(15) CONSTRAINT OO_Type_Nnull NOT NULL,
Manufacturer varchar2(20) CONSTRAINT OO_Manuf_Nnull NOT NULL
);

CREATE TABLE OneToOne_Employee(
EmpId number(7) CONSTRAINT OO_EmpPK PRIMARY KEY,
Name varchar2(25) CONSTRAINT OO_Ename_Nnull NOT NULL,
AllocatedAssetId varchar2(10) CONSTRAINT OO_Alloc_unique UNIQUE 
CONSTRAINT Emp_Fk REFERENCES OneToOne_Asset(AssetId));

INSERT INTO OnetoOne_Asset VALUES('Infy001','Laptop','Toshiba');
INSERT INTO OnetoOne_Asset VALUES('Infy003','Desktop','DELL');
INSERT INTO OnetoOne_Asset VALUES('Infy004','Laptop','HP');


INSERT INTO OneToOne_employee (EmpId,Name) VALUES(1001,'Scott');
INSERT INTO OneToOne_employee (EmpId,Name) VALUES(1002,'Jack');
INSERT INTO OneToOne_employee VALUES(1003,'Sita','Infy003');
INSERT INTO OneToOne_employee VALUES(1004,'Ahmad','Infy001');
INSERT INTO OneToOne_employee (EmpId,Name) VALUES(1005,'Joe');
INSERT INTO OneToOne_employee VALUES(1006,'Gosling','Infy004');

SELECT *  FROM OnetoOne_Asset;
SELECT * FROM OneToOne_Employee;
