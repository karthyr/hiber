package demo.io;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferOutputStreamTester {

	public static void main(String[] args) {
		
		try
		(
		 FileOutputStream fos = new FileOutputStream("resources/Data.dat"); // provide the name of file in which data has to be written
		 BufferedOutputStream bos = new BufferedOutputStream(fos) // stream chaining
		)
		{		
			
			bos.write(65);  // writing the content
			bos.write(66);
			bos.write(67);
			
			System.out.println("Data written to file successfully");
		}
		catch (IOException ioe) {
			System.err.println("ERROR: "+ioe.getMessage());
			
		}	
	}
	
}
