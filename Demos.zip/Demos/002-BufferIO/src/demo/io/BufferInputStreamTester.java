package demo.io;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class BufferInputStreamTester {

	public static void main(String[] args) {
		try
		(
			FileInputStream fis = new FileInputStream("resources/Data.dat"); // provide the location of the file; from which data has to be read
			BufferedInputStream bis = new BufferedInputStream(fis) // stream chaining
		)
		
		{
			System.out.println("Data in the file is:");
			
			while (bis.available()>0)  		// Terminating condition : checking if end of file is reached
											// available()  returns the sum of the number of bytes remaining to be read in the buffer 
			{							
				int i=bis.read();			 // Reads a byte of data from the input stream. 
											 
				System.out.print((byte) i+" "); 	// printing the byte data in the console
														
			}
				
		} catch (IOException ioe) {
			System.err.println("ERROR: "+ioe.getMessage());
		}	
	}
}
