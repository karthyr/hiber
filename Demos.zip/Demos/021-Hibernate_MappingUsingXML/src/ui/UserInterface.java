package ui;

import resources.HibernateUtility;
import bean.Customer;
import dao.CustomerDAO;

public class UserInterface {

	public static void main(String[] args) {
		try {
			addCustomer();
		} catch (Exception exception) {
			System.err.println("\nERROR: "+exception.getMessage());

		}finally{
			HibernateUtility.closeSessionFactory();
		}
	}

	public static void addCustomer() throws Exception {

		// Populating the Customer Details
		Customer customer = new Customer();
		customer.setCustomerId(1002);
		customer.setCustomerName("Gary");
		customer.setEmail("gary@infy.com");

		// Calling the Service method
		CustomerDAO dao = new CustomerDAO();
		String name = dao.addCustomer(customer);

		System.out.println("Customer registered successfully with customer name : "+ name);

	}
}
