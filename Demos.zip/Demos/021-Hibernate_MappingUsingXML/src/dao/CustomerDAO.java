package dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Customer;
import entity.CustomerEntity;

public class CustomerDAO  {

	/**
	 * This method persists the Customer details given in the Customer Bean object,in to the database 
	 * @param customer
	 * @return name of the customer persisted
	 * @throws Exception
	 * @author ETA
	 */
	public String addCustomer(Customer customer) throws Exception {

		// Creating the instances of Session Factory and session
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		CustomerEntity customerEntity = null;
		
		try {
			customerEntity = new CustomerEntity();
			customerEntity.setCustomerId(customer.getCustomerId());
			customerEntity.setEmail(customer.getEmail());
			customerEntity.setCustomerName(customer.getCustomerName());

			// Persisting the Object
			session.persist(customerEntity);
			// Committing the transaction
			session.beginTransaction().commit();

		} catch (HibernateException exception) {
			throw exception;
		} catch (Exception exception) {
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return customerEntity.getCustomerName();
	}

}
