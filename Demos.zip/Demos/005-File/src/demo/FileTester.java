package demo;

import java.io.File;

public class FileTester {

	public static void main(String[] args) {
		new FileTester().displayingAllFiles();
		//new FileTester().renameFile("resources/","File2","Filex");
		//new FileTester().deleteFile("resources/File1");
	}
		
	public void displayingAllFiles() {
		// Creating an Object
		File file = new File("resources/");

		// getting all the files
		File[] fileArr = file.listFiles();

		// printing the file name
		for (File f : fileArr) {
			System.out.println(f.getName());
		}
	}

	public void renameFile(String filePath, String oldFileName,String newfileName) {
		// Creating an Object
		File file = new File(filePath  + oldFileName);

		// renaming the file
		boolean b=file.renameTo(new File(filePath + newfileName));
		if(b){
			System.out.println("File renamed Successfully!!");
		}
		else{
			System.out.println("Requested file is not Exiting");
		}
	}

	public void deleteFile(String pathAndfileName) {
		// Creating an Object
		File file = new File(pathAndfileName);

		// deleting the file
		boolean b=file.delete();
		
		if(b){
			System.out.println("File Deleted Successfully");
		}
		else{
			System.out.println("Requested file is not Exiting");
		}
	}
	
	
}
