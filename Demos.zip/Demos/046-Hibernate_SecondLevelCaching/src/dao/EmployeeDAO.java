package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import entity.EmployeeEntity;


public class EmployeeDAO {

	public void getEmployee() {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		try {
			Session session = sessionFactory.openSession();
			EmployeeEntity employee1 = (EmployeeEntity) session.load(EmployeeEntity.class, 1001);
			System.out.println("Employee Name 1: "+ employee1.getEmployeeName());

			sessionFactory.getCache().evictEntity(EmployeeEntity.class, 1001);
			
			Session session2 = sessionFactory.openSession();
			EmployeeEntity employee2 = (EmployeeEntity) session2.load(EmployeeEntity.class, 1001);
			System.out.println("Employee Name 2: "+ employee2.getEmployeeName());

		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			HibernateUtility.closeSessionFactory();
		}
	}

	public static void main(String[] args) {
		new EmployeeDAO().getEmployee();
	}
}
