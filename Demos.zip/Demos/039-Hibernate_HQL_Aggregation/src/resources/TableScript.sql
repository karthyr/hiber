DROP TABLE HQL_Student CASCADE CONSTRAINTS;


CREATE TABLE HQL_Student(
studentName varchar2(25) CONSTRAINT HQL_SNamePK PRIMARY KEY,
marks number(4));

INSERT INTO HQL_Student VALUES('Mrudhu',78);
INSERT INTO HQL_Student VALUES('Nisha',65);
INSERT INTO HQL_Student VALUES('Raju',77);
COMMIT;

SELECT * FROM HQL_Student;

