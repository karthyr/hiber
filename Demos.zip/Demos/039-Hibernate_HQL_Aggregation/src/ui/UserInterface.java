package ui;

import dao.StudentDAO;
import resources.AppConfig;
import resources.HibernateUtility;


public class UserInterface {

	

	public static void aggregateFunctionsMax() {
		try {
			StudentDAO dao=new StudentDAO();
			Integer max = dao.aggregateFunctionsMax();
			System.out.println("Highest mark obtained among all Students is:");
			System.out.println(max);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void aggregateFunctionsMin() {
		try {
			StudentDAO dao=new StudentDAO();
			Integer min = dao.aggregateFunctionsMin();
			System.out.println("Lowest mark obtained among all Students is:");
			System.out.println(min);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void aggregateFunctionsSum() {
		try {
			StudentDAO dao=new StudentDAO();
			Long sum = dao.aggregateFunctionsSum();
			System.out.println("Sum of the marks obtained by all students is:");
			System.out.println(sum);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void aggregateFunctionsAvg() {
		try {
			StudentDAO dao=new StudentDAO();
			Double avg = dao.aggregateFunctionsAvg();
			System.out.println("Average of the marks obtained by all students is:");
			System.out.println(avg);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void aggregateFunctionsCount() {
		try {
			StudentDAO dao=new StudentDAO();
			Long count = dao.aggregateFunctionsCount();
			System.out.println("Total number of students are:");
			System.out.println(count);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void main(String args[]) {
	try{	
		//aggregateFunctionsMax();
		//aggregateFunctionsMin();
		//aggregateFunctionsAvg();
		//aggregateFunctionsSum();
		 aggregateFunctionsCount();
	} finally {
		HibernateUtility.closeSessionFactory();
	}
	}
}
