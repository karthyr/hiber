package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import bean.Employee;
import entity.EmployeeEntity;

public class LifeCycleAnnotationsDAO{
	
	/**
	 * Inserts a new employee into the database
	 * @param employee- employee details
	 * @throws Exception If there is a technical error
	 */
	//Database operations are logged in the file "DatabaseLog.log" in the log folder
	public void addEmployee(Employee employee)throws Exception {
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("LifeCycleAnnotations");;
		 EntityManager em;
			em = emf.createEntityManager();
		
		try {
			
		
						
			EmployeeEntity empEntity=new EmployeeEntity();
			empEntity.setEmpId(employee.getEmpId());
			empEntity.setName(employee.getName());
			empEntity.setBasicSalary(employee.getBasicSalary());
			empEntity.setAllowances(employee.getAllowances());
	
			em.getTransaction().begin();
			em.persist(empEntity);
			em.getTransaction().commit();
		}
		catch (PersistenceException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception); 
			throw new Exception("DAO.TECHNICAL_ERROR");
		} 
		catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		finally {
			if (em != null) {
				em.close();
				
			}
			if (emf != null) {
				emf.close();
				
			}
		}
	}
	/**
	 * Update the allowances for the accepted empId in the database
	 * @param empId- employeeId
	 * @Param allowances - New allowances
	 * @throws Exception If there is a technical error
	 */
	//Database operations are logged in the file "DatabaseLog.log" in the log folder
	public void updateEmployeeAllowances(Integer empId, Double allowances) throws Exception {
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("LifeCycleAnnotations");;
		 EntityManager em;
		 em = emf.createEntityManager();
		
		try {
			
			
						
			EmployeeEntity empEntity = em.find(EmployeeEntity.class,empId);
			
			em.getTransaction().begin();
			empEntity.setAllowances(allowances);
			em.getTransaction().commit();
		}
		catch (PersistenceException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception); 
			throw new Exception("DAO.TECHNICAL_ERROR");
		} 
		catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		finally {
			if (em != null) {
				em.close();
				
			}
			if (emf != null) {
				emf.close();
				
			}
		}
	}
	
	/**
	 * Deletes the employee details from the database
	 * @param empId- employeeId
	 * @throws Exception If there is a technical error
	 */
	//Database operations are logged in the file "DatabaseLog.log" in the log folder
	public void deleteEmployee(Integer empId) throws Exception {
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("LifeCycleAnnotations");;
		 EntityManager em;
			em = emf.createEntityManager();
			
		
		try {
			

			EmployeeEntity empEntity = em.find(EmployeeEntity.class,empId);
			
			em.getTransaction().begin();
			em.remove(empEntity);
			em.getTransaction().commit();
		}
		catch (PersistenceException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception); 
			throw new Exception("DAO.TECHNICAL_ERROR");
		} 
		catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		finally {
			if (em != null) {
				em.close();
				
			}
			if (emf != null) {
				emf.close();
				
			}
		}
	}
}
