package entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

@Entity

@Table (name="LifeCycleAnnotations_Employee")
public class EmployeeEntity {
	@Id
	private Integer empId;
	private String name;
	private Double basicSalary;
	private Double allowances;
	
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(Double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public Double getAllowances() {
		return allowances;
	}
	public void setAllowances(Double allowances) {
		this.allowances = allowances;
	}
	
	//Entity Life Cycle Annotations Starts here
	@PrePersist
	void prePersistLog(){
		DOMConfigurator.configure("src/resources/log4j.xml");
		Logger logger = Logger.getLogger(this.getClass());
		logger.info("PrePersist:A new entity instance will be inserted into employee table");
	}
	@PostPersist
	void postPersistLog() {
		DOMConfigurator.configure("src/resources/log4j.xml");
		Logger logger = Logger.getLogger(this.getClass());
		logger.info("PostPersist:A new entity instance is successfully inserted into employee table");
	}
	@PreUpdate
	void preUpdateLog() {
		DOMConfigurator.configure("src/resources/log4j.xml");
		Logger logger = Logger.getLogger(this.getClass());
		logger.info("PreUpdate:Entity instance will be updated");
	}
	@PostUpdate
	void postUpdateLog() {
		DOMConfigurator.configure("src/resources/log4j.xml");
		Logger logger = Logger.getLogger(this.getClass());
		logger.info("PostUpdate:Entity instance is successfully updated");
	}
	@PreRemove
	void preRemoveLog() {
		DOMConfigurator.configure("src/resources/log4j.xml");
		Logger logger = Logger.getLogger(this.getClass());
		logger.info("PreRemove:Entity instance will be removed from the employee table");
	}
	@PostRemove
	void postRemoveLog() {
		DOMConfigurator.configure("src/resources/log4j.xml");
		Logger logger = Logger.getLogger(this.getClass());
		logger.info("PostRemove:Entity instance is successfully removed");
	}
}
