package bean;
 
/**
 * Bean class to hold the user data
 * @author ETA
 */
public class Employee {
		private Integer empId;
		private String name;
		private Double basicSalary;
		private Double allowances;
		
		public Integer getEmpId() {
			return empId;
		}
		public void setEmpId(Integer empId) {
			this.empId = empId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Double getBasicSalary() {
			return basicSalary;
		}
		public void setBasicSalary(Double basicSalary) {
			this.basicSalary = basicSalary;
		}
		public Double getAllowances() {
			return allowances;
		}
		public void setAllowances(Double allowances) {
			this.allowances = allowances;
		}
}
