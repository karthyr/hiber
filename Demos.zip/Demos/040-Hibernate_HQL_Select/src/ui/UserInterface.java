package ui;

import java.util.List;

import dao.EmpDeptDAO;
import resources.AppConfig;
import resources.HibernateUtility;
import bean.Department;
import bean.Employee;
import bean.EmployeeDept;

public class UserInterface {

	public static void getEmployees() {
		List<Employee> employeeDetails = null;
		try {
			EmpDeptDAO dao=new EmpDeptDAO();
			employeeDetails = dao.getEmployeeDetails();

			System.out.println("List of Employees");
			System.out.println("==================");
			System.out
					.println("Employee Id        Employee Name      DeptCode");
			System.out
					.println("===============================================");
			for (Employee employee : employeeDetails) {
				System.out.println(employee.getEmpId() + "                  "
						+ employee.getName() + "       \t"
						+ employee.getDeptCode());
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getDepartmentDetails() {
		List<Department> deptDetails = null;
		try {
			EmpDeptDAO dao=new EmpDeptDAO();
			deptDetails = dao.getDepartmentDetails();
			System.out.println("Department Details");
			System.out.println("===================");
			System.out.println("Department Code            Department Name");
			for (Department department : deptDetails) {
				System.out
						.println(department.getDeptCode()
								+ "                        "
								+ department.getDeptName());
			}

		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getEmpDeptJoin() {
		List<EmployeeDept> empDeptDetails = null;
		try {
			EmpDeptDAO dao=new EmpDeptDAO();
			empDeptDetails = dao.getEmpDeptJoin();
			System.out.println("List of Employees ");
			System.out.println("==================");
			System.out
					.println("Employee Id        Employee Name   DeptCode      DeptName        NumberOfEmployees");
			System.out
					.println("============================================================================================");
			for (EmployeeDept employeeDept : empDeptDetails) {
				System.out.println(employeeDept.getEmpId() + "               "
						+ employeeDept.getName() + "     	        "
						+ employeeDept.getDeptCode() + " 	           "
						+ employeeDept.getDeptName() + " 	             "
						+ employeeDept.getNumberOfEmp());
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	
	

	public static void main(String args[]) {
	try{
		//getEmployees();
		//getDepartmentDetails();
		getEmpDeptJoin();
	} finally {
		HibernateUtility.closeSessionFactory();
	}
	}
}
