package bean;

public class EmployeeDept {
	private Integer empId;
	private String name;
	private Integer deptCode;
	private String deptName;
	private Integer numberOfEmp;
	public Integer getNumberOfEmp() {
		return numberOfEmp;
	}
	public void setNumberOfEmp(Integer numberOfEmp) {
		this.numberOfEmp = numberOfEmp;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(Integer deptCode) {
		this.deptCode = deptCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
}
