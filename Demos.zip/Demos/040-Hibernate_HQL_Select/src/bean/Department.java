package bean;

public class Department {
	private Integer deptCode;
	private String deptName;
	private Integer numberOfEmp;
	public Integer getNumberOfEmp() {
		return numberOfEmp;
	}
	public void setNumberOfEmp(Integer numberOfEmp) {
		this.numberOfEmp = numberOfEmp;
	}
	public Integer getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(Integer deptCode) {
		this.deptCode = deptCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
}
