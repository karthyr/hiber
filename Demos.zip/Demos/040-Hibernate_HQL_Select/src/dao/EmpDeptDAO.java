package dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Department;
import bean.Employee;
import bean.EmployeeDept;
import entity.DepartmentEntity;
@SuppressWarnings("unchecked")
public class EmpDeptDAO{

	public List<Employee> getEmployeeDetails() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Employee> employeeDetails = null;
		try {
			employeeDetails = new ArrayList<Employee>();
			Query query = session
					.createQuery("Select empId,name,deptCode from EmployeeEntity as emp");
		
			//Returns a list
			List<Object[]> results = query.list();
			for (Object[] object : results) {

				Employee employee = new Employee();
				/*
				 * Retrieving Employee Details from the Database in the same order as
				 * specified in the query
				 */
				employee.setEmpId((Integer) object[0]);
				employee.setName((String) object[1]);
				employee.setDeptCode((Integer) object[2]);
				employeeDetails.add(employee);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return employeeDetails;
	}

	public List<EmployeeDept> getEmpDeptJoin() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<EmployeeDept> result = null;
		try {
			// Query to get details from two tables using JOINS
			Query query = session
					.createQuery("select emp.empId,emp.name,emp.deptCode,dept.deptName,"
							+ "dept.numberOfEmp from EmployeeEntity emp,"
							+ "DepartmentEntity dept where emp.deptCode=dept.deptCode");
			
			List<Object[]> obj = query.list();
			result = new ArrayList<EmployeeDept>();
			for (Object[] objects : obj) {
				EmployeeDept employeeDept = new EmployeeDept();
				employeeDept.setEmpId((Integer) objects[0]);
				employeeDept.setName((String) objects[1]);
				employeeDept.setDeptCode((Integer) objects[2]);
				employeeDept.setDeptName((String) objects[3]);
				employeeDept.setNumberOfEmp((Integer) objects[4]);
				result.add(employeeDept);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return result;
	}


	public List<Department> getDepartmentDetails() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Department> deptDetails = null;
		try {
			// SELECT clause is optional in HQL
			Query query = session.createQuery("from DepartmentEntity");
			List<DepartmentEntity> list = query.list();
			deptDetails = new ArrayList<Department>();
			for (DepartmentEntity departmentEntity : list) {
				Department department = new Department();
				// the retrieved data will be in the order as that in the table
				department.setDeptCode(departmentEntity.getDeptCode());
				department.setDeptName(departmentEntity.getDeptName());
				deptDetails.add(department);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return deptDetails;
	}

}
