package bean;

public class ContractEmployee extends Employee {
	private Double professionalCharges;
	private String areaOfSpecialization;

	public Double getProfessionalCharges() {
		return professionalCharges;
	}

	public void setProfessionalCharges(Double professionalCharges) {
		this.professionalCharges = professionalCharges;
	}

	public String getAreaOfSpecialization() {
		return areaOfSpecialization;
	}

	public void setAreaOfSpecialization(String areaOfSpecialization) {
		this.areaOfSpecialization = areaOfSpecialization;
	}

}
