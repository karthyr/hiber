DROP TABLE SingleTable_employee CASCADE CONSTRAINTS;

CREATE TABLE SingleTable_employee(
EmpId number(7) CONSTRAINT ST_EmpPK PRIMARY KEY,
Name varchar2(25) CONSTRAINT ST_Emp_Nnull NOT NULL,
BasicSalary  number(10,2) CONSTRAINT ST_BS_Check CHECK(BasicSalary > 0),
Allowances number(10,2) CONSTRAINT ST_Allowances_Check CHECK(Allowances > 0),
AreaOfSpecialization varchar2(15),
ProfessionalCharges number(10,2) CONSTRAINT ST_EPC_Check CHECK(ProfessionalCharges > 0),
EmployeeType varchar2(15));

INSERT INTO SingleTable_employee VALUES(1001,'Scott',15000,4500,NULL,NULL,'Permanent');
INSERT INTO SingleTable_employee VALUES(4001,'Jack',NULL,NULL,'Architecture',5000,'Contract');
COMMIT;

SELECT * from SingleTable_employee;
