package entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity

//Value to be put in the extra column during persist 
@DiscriminatorValue("Contract")
public class ContractEmployeeEntity extends EmployeeEntity {
	private Double professionalCharges;
	private String areaOfSpecialization;

	public Double getProfessionalCharges() {
		return professionalCharges;
	}

	public void setProfessionalCharges(Double professionalCharges) {
		this.professionalCharges = professionalCharges;
	}

	public String getAreaOfSpecialization() {
		return areaOfSpecialization;
	}

	public void setAreaOfSpecialization(String areaOfSpecialization) {
		this.areaOfSpecialization = areaOfSpecialization;
	}

}
