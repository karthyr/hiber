package entity;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name = "SingleTable_employee")

// Specifying the strategy type
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)

// Extra Column to tell which sub class the row belongs to (Permanent or Contract)
@DiscriminatorColumn(name = "EmployeeType")
public class EmployeeEntity {
	@Id
	private Integer empId;
	private String name;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
