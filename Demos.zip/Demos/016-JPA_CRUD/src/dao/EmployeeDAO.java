package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import bean.Employee;
import entity.EmployeeEntity;

public class EmployeeDAO {
	/**
	 * Inserts a new employee into the database
	 * @param employeeTO
	 *            - employee details
	 * @throws Exception
	 */
	public void addEmployee(Employee employee) throws Exception {
		EntityManagerFactory emf = null;
		EntityManager em = null;

		try {
			emf = Persistence.createEntityManagerFactory("Demo");
			em = emf.createEntityManager();

			EmployeeEntity empEntity = new EmployeeEntity();
			empEntity.setEmployeeId(employee.getEmployeeId());
			empEntity.setEmployeeName(employee.getEmployeeName());
			empEntity.setBasicSalary(employee.getBasicSalary());
			empEntity.setAllowances(employee.getAllowances());

			em.getTransaction().begin();
			em.persist(empEntity);
			em.getTransaction().commit();
		} catch (PersistenceException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (em != null) {
				em.close();
			}
			if (emf != null) {
				emf.close();
			}
		}
	}

	/**
	 * Update the allowances for the accepted empId in the database
	 * 
	 * @param employeeId
	 * @Param allowances
	 * @throws Exception
	 */
	public void updateEmployeeAllowances(Integer employeeId, Double allowances)
			throws Exception {
		EntityManagerFactory emf = null;
		EntityManager em = null;

		try {
			emf = Persistence.createEntityManagerFactory("Demo");
			em = emf.createEntityManager();

			EmployeeEntity empEntity = em
					.find(EmployeeEntity.class, employeeId);

			em.getTransaction().begin();
			empEntity.setAllowances(allowances);
			em.getTransaction().commit();
		} catch (PersistenceException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (em != null) {
				em.close();
			}
			if (emf != null) {
				emf.close();
			}
		}
	}

	/**
	 * Deletes the employee details from the database
	 * 
	 * @param empId
	 *            - employeeId
	 * @throws Exception
	 * @author ETA
	 */
	public void deleteEmployee(Integer employeeId) throws Exception {
		EntityManagerFactory emf = null;
		EntityManager em = null;

		try {
			emf = Persistence.createEntityManagerFactory("Demo");
			em = emf.createEntityManager();

			EmployeeEntity empEntity = em
					.find(EmployeeEntity.class, employeeId);

			em.getTransaction().begin();
			em.remove(empEntity);
			em.getTransaction().commit();
		} catch (PersistenceException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (em != null) {
				em.close();
			}
			if (emf != null) {
				emf.close();
			}
		}
	}

	/**
	 * Merges the employee details from the database
	 * <ul>
	 * <li>If the employee record is present, then updates the same
	 * <li>Else, creates a new employee record with the given details
	 * </ul>
	 * 
	 * @param employee
	 * @throws Exception
	 */
	public void mergeEmployee(Employee employee) throws Exception {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		try {
			emf = Persistence.createEntityManagerFactory("Demo");
			em = emf.createEntityManager();

			EmployeeEntity employeeEntity = new EmployeeEntity();
			employeeEntity.setEmployeeId(employee.getEmployeeId());
			employeeEntity.setEmployeeName(employee.getEmployeeName());
			employeeEntity.setBasicSalary(employee.getBasicSalary());
			employeeEntity.setAllowances(employee.getAllowances());

			em.getTransaction().begin();
			em.merge(employeeEntity);
			em.getTransaction().commit();
		} catch (PersistenceException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (em != null) {
				em.close();
			}
			if (emf != null) {
				emf.close();
			}
		}
	}

	/**
	 * Retrieves the details of employee from the database
	 * 
	 * @param employeeId
	 * @return Employee
	 * @throws Exception
	 */
	public Employee getEmployeeDetails(Integer employeeId) throws Exception {

		Employee employee = null;
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		EmployeeEntity employeeEntity = null;
		try {

			// Creating Entity Manager Factory using same persistence unit name
			// as
			// in persistence.xml
			entityManagerFactory = Persistence
					.createEntityManagerFactory("Demo");
			// Creating Entity Manager
			entityManager = entityManagerFactory.createEntityManager();
			// No need to begin the transaction for a read operation
			// find operation works on the primary key
			employeeEntity = entityManager.find(EmployeeEntity.class,
					employeeId);
			employee = new Employee();
			employee.setEmployeeId(employeeEntity.getEmployeeId());
			employee.setEmployeeName(employeeEntity.getEmployeeName());
			employee.setBasicSalary(employeeEntity.getBasicSalary());
			employee.setAllowances(employeeEntity.getAllowances());
		} catch (PersistenceException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
			if (entityManagerFactory != null) {
				entityManagerFactory.close();
			}
		}
		return employee;
	}
}
