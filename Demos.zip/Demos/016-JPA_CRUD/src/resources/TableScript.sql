DROP TABLE Employee CASCADE constraint;

CREATE TABLE Employee(
EmpId number(7) CONSTRAINT C_EmpPK PRIMARY KEY,
Name varchar2(25) CONSTRAINT C_EName_Nnull NOT NULL,
BasicSalary Number(10,2) CONSTRAINT C_BS_Nnull NOT NULL
CONSTRAINT C_BS_Check CHECK(BasicSalary > 0),
Allowances Number(10,2) CONSTRAINT C_AL_Nnull NOT NULL
CONSTRAINT C_AL_Check CHECK(Allowances > 0)
);

INSERT INTO Employee VALUES(1001,'Scott', 25000,4000);
INSERT INTO Employee VALUES(1002,'Jack',30000,3000);
INSERT INTO Employee VALUES(1003,'Gary',26000,5000);
INSERT INTO Employee VALUES(1004,'Robert',12500,5000);


SELECT * FROM Employee;
