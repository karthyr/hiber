package ui;

import java.util.List;

import dao.AssetAllocationDAO;
import resources.AppConfig;
import resources.HibernateUtility;
import bean.Employee;

public class UserInterface {

	public static void innerJoin() {
		try {
			AssetAllocationDAO dao=new AssetAllocationDAO();
			List<Employee> employeeList = dao.innerJoin();
			System.out.println("Inner Join");
			System.out.println("EmployeeId\tName\t\tAssetId");
			for (Employee employee : employeeList) {
				System.out.println(employee.getEmpId() + "\t\t"
						+ employee.getName() + "\t\t" + employee.getAssetId());
			}

		} catch (Exception e) {
		
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void rightOuterJoin() {
		try {
			AssetAllocationDAO dao=new AssetAllocationDAO();
			List<Employee> employeeList = dao
					.rightOuterJoin();
			System.out.println("Right Outer Join");
			System.out.println("EmployeeId\tName\t\tAssetId");
			for (Employee employee : employeeList) {
				System.out.println(employee.getEmpId() + "\t\t"
						+ employee.getName() + "\t\t" + employee.getAssetId());
			}

		} catch (Exception e) {
		
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void leftOuterJoin() {
		try {
			AssetAllocationDAO dao=new AssetAllocationDAO();
			List<Employee> employeeList = dao
					.leftOuterJoin();
			System.out.println("Left Outer Join");
			System.out.println("EmployeeId\tName\t\tAssetId");
			for (Employee employee : employeeList) {
				System.out.println(employee.getEmpId() + "\t\t"
						+ employee.getName() + "\t\t" + employee.getAssetId());
			}

		} catch (Exception e) {
		
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void main(String args[]) {
	try
	{
		//innerJoin();
		//rightOuterJoin();
		leftOuterJoin();
	} finally {
		HibernateUtility.closeSessionFactory();
	}
	}
}
