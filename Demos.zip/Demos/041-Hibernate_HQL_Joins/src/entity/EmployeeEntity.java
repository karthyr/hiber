package entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "OneToOne_Employee")
public class EmployeeEntity {
	@Id
	private Integer empId;
	private String name;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="allocatedAssetId",unique=true)
	private AssetEntity assetEntity;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
