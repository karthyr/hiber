package dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Employee;

public class AssetAllocationDAO{
	/**
	 * Fetches the employee details and the corresponding asset details from the
	 * database using inner join 
	 * 
	 * @throws Exception
	 *             if there is a technical error
	 */
	public List<Employee> innerJoin() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Employee> employeeList=null;
		Employee employee=null;
		try {
			Query query = session
					.createQuery("select emp.empId,emp.name,emp.assetEntity.assetId from EmployeeEntity emp "
							+ "INNER JOIN emp.assetEntity a");
			List<Object[]> list = query.list();
			employeeList=new ArrayList<Employee>();
			for (Object[] objects : list) {
				employee=new Employee();
				employee.setEmpId((Integer)objects[0]);
				employee.setName((String)objects[1]);
				employee.setAssetId((String)objects[2]);
				employeeList.add(employee);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return employeeList;
	}
	/**
	 * Fetches the employee details and the corresponding asset details from the
	 * database using right outer join (abbreviated as RIGHT JOIN)
	 * 
	 * @throws Exception
	 *             if there is a technical error
	 */
	public List<Employee> rightOuterJoin() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Employee> employeeList=null;
		Employee employee=null;
		try {
		Query query = session
					.createQuery("select emp.empId,emp.name,emp.assetEntity.assetId  from EmployeeEntity emp RIGHT JOIN "
							+ "emp.assetEntity a");
			
			List<Object[]> list = query.list();
			employeeList=new ArrayList<Employee>();
			for (Object[] objects : list) {
				employee=new Employee();
				employee.setEmpId((Integer)objects[0]);
				employee.setName((String)objects[1]);
				employee.setAssetId((String)objects[2]);
				employeeList.add(employee);
			}
		} catch (HibernateException exception) {
		
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return employeeList;
	}
	/**
	 * Fetches the employee details and the corresponding asset details from the
	 * database using left outer join (abbreviated as LEFT JOIN)
	 * 
	 * @throws Exception
	 *             if there is a technical error
	 */
	public List<Employee> leftOuterJoin() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Employee> employeeList=null;
		Employee employee=null;
		try {
			Query query = session
					.createQuery("select emp.empId,emp.name,emp.assetEntity.assetId from EmployeeEntity emp LEFT OUTER JOIN "
							+ "emp.assetEntity a ");
			List<Object[]> list = query.list();
			employeeList=new ArrayList<Employee>();
			for (Object[] objects : list) {
				employee=new Employee();
				employee.setEmpId((Integer)objects[0]);
				employee.setName((String)objects[1]);
				employee.setAssetId((String)objects[2]);
				employeeList.add(employee);
			}
		} catch (HibernateException exception) {
			
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return employeeList;
	}
	
	
}
