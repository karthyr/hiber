package resources;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtility {

	private static SessionFactory sessionFactory = getSessionFactory();

	private static SessionFactory getSessionFactory() {
		try {
			if (sessionFactory==null) {

				Configuration configuration = new Configuration();
				// Hibernate related informations
				configuration.setProperty("hibernate.dialect","org.hibernate.dialect.Oracle10gDialect");
				// Providing the Database Credentials and URL
				configuration.setProperty("hibernate.connection.driver_class","oracle.jdbc.driver.OracleDriver");
				configuration.setProperty("hibernate.connection.url","jdbc:oracle:thin:@localhost:1521:xe");
				configuration.setProperty("hibernate.connection.username", "system");
				configuration.setProperty("hibernate.connection.password", "oracle");
				// Setting the Database properties
				configuration.addAnnotatedClass(entity.CustomerEntity.class);
				// Creating SessionFactory and session instances using the Configuration and serviceRegistry.
				ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
				sessionFactory = configuration.buildSessionFactory(serviceRegistry);
			}
		} catch (Exception e) {
			System.err.println("ERROR : HibernateUtility :"+e.getMessage());
			throw e;
		}
		return sessionFactory;
	}

	public static SessionFactory createSessionFactory() {
		return getSessionFactory();
	}

	public static void closeSessionFactory() {
		if(!sessionFactory.isClosed() ||  sessionFactory!=null ){
			sessionFactory.close();
		}
	}
}
