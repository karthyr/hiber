DROP TABLE Customer CASCADE CONSTRAINTS;

CREATE TABLE Customer(
ID Number(5) CONSTRAINT C_Pkey PRIMARY KEY,
Name Varchar2(25) CONSTRAINT C_Nnull NOT NULL,
email Varchar2(25));

INSERT INTO Customer VALUES(1001,'Scott','scott@infy.com');

SELECT * from Customer;