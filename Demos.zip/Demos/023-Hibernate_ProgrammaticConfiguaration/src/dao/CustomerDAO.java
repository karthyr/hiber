package dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Customer;
import entity.CustomerEntity;

public class CustomerDAO{

	
	/**
	 * This method persists the Customer details given in the Customer Bean object,in to the database 
	 * @param customer
	 * @return name of the customer persisted
	 * @throws Exception
	 * @author ETA
	 */
	public String addCustomer(Customer customer) throws Exception {
		CustomerEntity customerEntity = null;
		Session session=null;
		SessionFactory sessionFactory=null;
		try {
			sessionFactory=HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();
			
			session.getTransaction().begin();
			
			customerEntity = new CustomerEntity();
			customerEntity.setCustomerId(customer.getCustomerId());
			customerEntity.setEmail(customer.getEmail());
			customerEntity.setName(customer.getName());

			// Persist the Customer Entity
			session.persist(customerEntity);

			// Commit the transaction
			session.getTransaction().commit();
		} catch (HibernateException exception) {
			throw exception;
		} catch (Exception exception) {
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return customer.getName();
	}

}
