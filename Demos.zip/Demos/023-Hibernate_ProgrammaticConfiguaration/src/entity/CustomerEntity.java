package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * Entity Class
 * @author ETA
 *
 */
@Entity 
@Table(name = "Customer")
public class CustomerEntity {
	
	@Id  // Identifier (Primary attribute)
	@Column(name="id")
	private Integer customerId;
	private String name;
	private String email;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
