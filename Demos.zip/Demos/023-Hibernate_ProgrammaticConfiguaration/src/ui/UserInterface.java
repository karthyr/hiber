package ui;

import resources.HibernateUtility;
import bean.Customer;
import dao.CustomerDAO;

public class UserInterface {

	public static void main(String[] args) {
		try {
			addCustomer();
		} catch (Exception exception) {
			System.err.println("\nERROR: "+exception.getMessage());
		}finally{
			HibernateUtility.closeSessionFactory();
		}
	}

	public static void addCustomer() throws Exception {
		Customer customer = new Customer();
		customer.setCustomerId(1005);
		customer.setName("Mark");
		customer.setEmail("mark@infy.com");
		
		CustomerDAO dao = new CustomerDAO();
		String name = dao.addCustomer(customer);
		
		System.out.println("Customer succesfully added with customer name : "+name);

	}
}
