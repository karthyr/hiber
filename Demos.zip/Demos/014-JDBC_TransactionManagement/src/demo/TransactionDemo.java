package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TransactionDemo {

	public static void main(String[] args) {
		try {
			updateDetails();
		} catch (Exception e) {
			System.err.println("ERROR: "+e.getMessage());
		}
	}

	public static void updateDetails() throws SQLException {

		String insertTableSQL = "INSERT INTO customer VALUES (?,?,?)";
		String updateTableSQL = "UPDATE customer SET EMAILID =? WHERE CUSTOMERID = ?";

		Connection connection= DriverManager.getConnection("jdbc:oracle:thin:system/oracle@localhost:1521:XE");
		try (	PreparedStatement preparedStatementInsert = connection.prepareStatement(insertTableSQL);
				PreparedStatement preparedStatementUpdate = connection.prepareStatement(updateTableSQL)) {

			// setting the auto commit to false
			connection.setAutoCommit(false);

			System.out.println("First Update: To update a the user name");
			System.out.println("------------------------------------------------");
				preparedStatementUpdate.setString(1,"jack@infy.com");
				preparedStatementUpdate.setInt(2, 1001);
				int noOfRowsUpdated = preparedStatementUpdate.executeUpdate();
				System.out.println(noOfRowsUpdated + " row(s) updated");

			System.out.println("------------------------------------------------");
			System.out.println("Second Update: To insert a new record");
			System.out.println("------------------------------------------------");
				preparedStatementInsert.setInt(1, 1004);
				preparedStatementInsert.setString(2, "Sree");
				//preparedStatementInsert.setString(2, "******************VALUE TO LARGE****************");
				preparedStatementInsert.setString(3, "sree@infy.com");
				noOfRowsUpdated = preparedStatementInsert.executeUpdate();
				System.out.println(noOfRowsUpdated + " row(s) updated");
			System.out.println("------------------------------------------------");
			// commit connection
			connection.commit();

			System.out.println("Transaction committed");
			
		} catch (Exception exception) {
			System.err.println("ERROR: "+exception.getMessage());
			// Roll back connection
			connection.rollback();
			System.err.println("INFO : Connection Rolled Back");
		}
	}

}
