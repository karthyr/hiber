DROP TABLE customer cascade constraints;

CREATE TABLE customer
(customerId NUMBER(4) primary key,
customerName VARCHAR2(10),
emailId VARCHAR2(20));
 
insert into customer values(1001,'jack','abc@infy.com');

select * from customer;