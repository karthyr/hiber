package jpa;

import java.io.Serializable;

public interface JPAInterface {
	
	public void insert(Object obj) throws Exception;
	public void update(Object obj) throws Exception;
	public void delete(Object obj) throws Exception;
	public Object retrieve(Serializable id) throws Exception;
}
