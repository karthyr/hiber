package myApplication;

import jpa.JPAInterface;
import jpaProviderA.JPAProviderA;
import jpaProviderB.JPAProviderB;

public class Application {

	
	public static void main(String[] args) {
		try {
			Object persistenceObject=new Object();
			
			JPAInterface jpa=new JPAProviderA();
			//JPAInterface jpa=new JPAProviderB();
			
			//jpa.insert(persistenceObject);
			
			//jpa.update(persistenceObject);
			
			// jpa.retrieve(1001);
			
			//jpa.delete(persistenceObject);
			
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	
}
