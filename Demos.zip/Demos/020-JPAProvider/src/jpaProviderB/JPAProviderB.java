package jpaProviderB;

import java.io.Serializable;

import jpa.JPAInterface;

public class JPAProviderB implements JPAInterface {

	@Override
	public void insert(Object obj) throws Exception {
		
		// CODE to implement insertion of data
		
		System.out.println("Data Persisted Successfully");

	}

	@Override
	public void update(Object obj) throws Exception {
		
		// CODE to implement updation of data
		
		System.out.println("Data Updated Successfully");

	}

	@Override
	public void delete(Object obj) throws Exception {
		
		// CODE to implement deletion of data
		
		System.out.println("Deleted Successfully");

	}

	@Override
	public Object retrieve(Serializable id) throws Exception {
		
		// CODE to implement retrieval of data
		
		System.out.println("Retrieved Successfully");
		
		return new String("Gary");
		
	}

}
