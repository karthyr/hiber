//Import the necessary packages
package demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CallableStatementDemo {

	public void addCustomer() {

		try (Connection connection = DriverManager
				.getConnection("jdbc:oracle:thin:system/oracle@localhost:2521:xe");
				CallableStatement callableStatement = connection
						.prepareCall("{call insertCustomer(?,?,?)}");) {

			// Setting the parameter
			callableStatement.setInt(1, 1001);
			callableStatement.setString(2, "John");
			callableStatement.setString(3, "John@infy.com");

			// Executing the statement
			callableStatement.execute();
							
			System.out.println("Customer added successfully");

		} catch (SQLException exception) {
			System.err.println("ERROR: " + exception.getMessage());
		} catch (Exception exception) {
			System.err.println("ERROR: " + exception.getMessage());
		}

	}

	public static void main(String[] args) {
		new CallableStatementDemo().addCustomer();
	}
}
