-- Run this on your oracle server using SQL plus or Oracle XE
DROP TABLE customers CASCADE CONSTRAINTS;

create table customers (
id number(4) primary key,
name varchar2(10),
email varchar2(20)
);

create or replace procedure insertCustomer(p_id CUSTOMERS.ID%TYPE,
p_name CUSTOMERS.NAME%TYPE,
p_email CUSTOMERS.EMAIL%TYPE)
is
begin
insert into customers values(p_id,p_name,p_email);
end;