drop table employee cascade constraints;
 
create table employee(
employeeid number(6) primary key,
employeename varchar2(25)
);
 
insert into employee values(1001,'Scott');
insert into employee values(1002,'Harry');
insert into employee values(1003,'Robert');
 
 
select * from employee;