package demo.io;

import java.io.FileWriter;
import java.io.IOException;



public class FileWriterTester {

	public static void main(String[] args) {
		try(FileWriter fw = new FileWriter("resources/Data.txt"))// provide the name for the file into which data has to be written 
		
		{
			
			// writing the content
			fw.write('A');
			fw.write('a');
			fw.write('*');
			fw.write(65);
			
			System.out.println("Data written successfully");
			
		}
		catch(IOException ioe) {
			 System.err.println("ERROR: "+ioe.getMessage());

		}		
	}
	
}
