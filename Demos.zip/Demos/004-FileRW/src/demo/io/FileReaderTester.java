package demo.io;

import java.io.FileReader;
import java.io.IOException;

public class FileReaderTester {

	public static void main(String[] args) {
		try 
		
		(FileReader fr = new FileReader("resources/Data.txt")) //the location of the file from which data has to be read
		
		{
			
			System.out.println("Data in the file is:");
			int i  = fr.read();
			while(i != -1) 		// to check for the end of file
			{
				System.out.println((char)i);
				i = fr.read(); // reading the content
			}
			
			
			
		}
		
		catch(IOException ioe) {
			 System.err.println("ERROR: "+ioe.getMessage());

		}		
	}
	
}
