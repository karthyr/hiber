package dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.EmployeeDept;
@SuppressWarnings("unchecked")
public class EmpDeptDAO{

	public List<EmployeeDept> getEmpDeptSubQuery() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<EmployeeDept> result = null;
		try {
			Query query = session
					.createQuery("select emp.empId,emp.name,emp.deptCode from EmployeeEntity emp "
							+ "where emp.deptCode in(select dept.deptCode from DepartmentEntity dept "
							+ "where dept.numberOfEmp > 40)");
		
			List<Object[]> obj = query.list();
			result = new ArrayList<EmployeeDept>();
			for (Object[] objects : obj) {
				EmployeeDept employeeDept = new EmployeeDept();
				employeeDept.setEmpId((Integer) objects[0]);
				employeeDept.setName((String) objects[1]);
				employeeDept.setDeptCode((Integer) objects[2]);
				result.add(employeeDept);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return result;
	}

}
