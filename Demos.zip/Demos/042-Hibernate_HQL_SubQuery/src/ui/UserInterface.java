package ui;

import java.util.List;

import dao.EmpDeptDAO;
import resources.AppConfig;
import resources.HibernateUtility;
import bean.EmployeeDept;

public class UserInterface {

	

	public static void getEmpDeptSubQuery() {
		List<EmployeeDept> empDeptDetails = null;
		try {
			EmpDeptDAO dao=new EmpDeptDAO();		
			empDeptDetails = dao.getEmpDeptSubQuery();
			System.out.println("List of Employees ");
			System.out.println("==================");
			System.out
					.println("Employee Id        Employee Name      DeptCode  ");
			System.out
					.println("==============================================");
			for (EmployeeDept employeeDept : empDeptDetails) {
				System.out.println(employeeDept.getEmpId() + "               "
						+ employeeDept.getName() + "             "
						+ employeeDept.getDeptCode() + "            ");
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	

	public static void main(String args[]) {
	try{	
		getEmpDeptSubQuery();
	} finally {
		HibernateUtility.closeSessionFactory();
	}
	}
}
