package demo.io;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class DataInputStreamTester {

	public static void main(String[] args) {
		try
		(
				FileInputStream fis = new FileInputStream("resources/Data.dat"); // provide the name of the file from which data has to be read
				DataInputStream dis = new DataInputStream(fis); 		// stream chaining
		)
		
		{
			System.out.println("Data stored in the file is:\n");
			// reading the content and printing values in console 
			System.out.println("Integer value :"+dis.readInt());
			System.out.println("Double value:"+dis.readDouble());
			System.out.println("Float value :"+ dis.readFloat());
		}
		catch (IOException ioe) {
			System.err.println("ERROR: "+ioe.getMessage());
		}		
	}
	
}
