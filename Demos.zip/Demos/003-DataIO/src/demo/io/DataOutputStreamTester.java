package demo.io;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataOutputStreamTester {

	public static void main(String[] args) {
		try 
		(
				FileOutputStream fos = new FileOutputStream("resources/Data.dat");//provide the name of file in which data has to be written
				DataOutputStream dos = new DataOutputStream(fos);  // stream chaining
		)
		
		{
			
			dos.writeInt(100);
			dos.writeDouble(56.78);
			dos.writeFloat(4.5f);
			System.out.println("Data written successfully");
		}
		catch (IOException ioe) {
			System.err.println("ERROR: "+ioe.getMessage());
		}	
	}
	
}
