package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;



public class ResultSetMetaDataDemo {

	public static void main(String args[])throws Exception{
		getMetaData();
	}

	public static void getMetaData(){
		try(Connection connection = DriverManager.getConnection("jdbc:oracle:thin:system/oracle@localhost:1521:XE");
				PreparedStatement prepareStatement=connection.prepareStatement("select * from customer");){
			
			ResultSet resultSet=prepareStatement.executeQuery();
			ResultSetMetaData metaData=resultSet.getMetaData();

			// Total number of columns
			
			System.out.println("Number of Columns  : "+metaData.getColumnCount());
			
			//Fetching metadata for column 1 
			for (int col=1;col<=metaData.getColumnCount();col++) {
				System.out.println("--------------------------------------------");
				System.out.println("DB Column Name  : "+metaData.getColumnName(col));
				System.out.println("DB Column Type  : "+metaData.getColumnTypeName(col));
				System.out.println("Size : "+metaData.getPrecision(col));
				System.out.println("--------------------------------------------");
			}
			
			
		}catch(Exception exception){
			System.err.println("ERROR: "+exception.getMessage());
		}

	}

}
