package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "Employee")
@TableGenerator(name="tableGenerator",table="DB_EmployeePkeyTable",valueColumnName="NextValue",pkColumnName="EmployeePKey",pkColumnValue="EmployeeId",allocationSize=1)
public class EmployeeEntity {
	@Id
	@GeneratedValue(generator="tableGenerator",strategy=GenerationType.TABLE)
	@Column(name = "empId")
	private Integer employeeId;
	@Column(name = "name")
	private String employeeName;
	private Double basicSalary;
	private Double allowances;

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(Double basicSalary) {
		this.basicSalary = basicSalary;
	}

	public Double getAllowances() {
		return allowances;
	}

	public void setAllowances(Double allowances) {
		this.allowances = allowances;
	}

}