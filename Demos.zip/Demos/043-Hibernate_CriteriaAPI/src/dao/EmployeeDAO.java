package dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import resources.HibernateUtility;
import bean.Employee;
import entity.EmployeeEntity;

@SuppressWarnings({ "unchecked", "unused" })
public class EmployeeDAO{

	public List<Employee> criteriaInterface() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Employee> result = null;
		try {
			/*
			 * createCriteria() method can be used to create a Criteria object
			 * that returns instances of the persistence object's class
			 * (Rows from the Database)
			 */
			Criteria criteria = session.createCriteria(EmployeeEntity.class);
			List<EmployeeEntity> list = criteria.list();
			result = new ArrayList<Employee>();
			for (EmployeeEntity employeeEntity : list) {
				Employee employee = new Employee();
				employee.setEmpId(employeeEntity.getEmpId());
				employee.setName(employeeEntity.getName());
				employee.setDeptCode(employeeEntity.getDeptCode());
				result.add(employee);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
			
		}
		return result;
	}

	public List<Employee> criteriaOrder() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Employee> result = null;
		try {
			Criteria criteria = session.createCriteria(EmployeeEntity.class);

			/*
			 * The Employee details are fetched based on the "empId" in descending
			 * order. There is also a method for ascending order i.e.
			 * "Order.asc"
			 */
			criteria.addOrder(Order.desc("empId"));
			List<EmployeeEntity> list = criteria.list();
			result = new ArrayList<Employee>();
			for (EmployeeEntity employeeEntity : list) {
				Employee employee = new Employee();
				employee.setEmpId(employeeEntity.getEmpId());
				employee.setName(employeeEntity.getName());
				employee.setDeptCode(employeeEntity.getDeptCode());
				result.add(employee);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
			
		}
		return result;
	}

	public List<Employee> criteriaRestrictions() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Employee> result = null;
		try {
			Criteria criteria = session.createCriteria(EmployeeEntity.class);

			/*
			 * There are many methods in Restrictions criterion like gt(greater
			 * than),ge(greater than or equal to),isEmpty and so on..
			 */

			/*
			 * Fetching Employee Details from the Database where the name Field
			 * is not NULL and the empId greater than "1002"
			 */
				criteria.add(Restrictions.isNotNull("name")).add(
					Restrictions.gt("empId", 1002));
		
			
			/*//For Putting multiple Restrictions or Criteria
			Criterion deptcode = Restrictions.eq("deptCode", 10);
			Criterion name = Restrictions.ilike("name","s%");
			//LogicalExpression andExp = Restrictions.and(deptcode, name);
			LogicalExpression orExp=Restrictions.or(deptcode, name);
			criteria.add(orExp);*/
			List<EmployeeEntity> list = criteria.list();
			
			result = new ArrayList<Employee>();
			for (EmployeeEntity employeeEntity : list) {
				Employee employee = new Employee();
				employee.setEmpId(employeeEntity.getEmpId());
				employee.setName(employeeEntity.getName());
				employee.setDeptCode(employeeEntity.getDeptCode());
				result.add(employee);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return result;
	}
}
