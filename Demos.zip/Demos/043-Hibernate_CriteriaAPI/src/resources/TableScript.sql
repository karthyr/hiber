DROP TABLE Employee CASCADE CONSTRAINTS;


CREATE TABLE Employee(
EmpId number(7) CONSTRAINT EmpPK PRIMARY KEY,
Name varchar2(25) CONSTRAINT ENameNnull NOT NULL,
DeptCode number(4) );


INSERT INTO Employee VALUES(1001,'Scott',10);
INSERT INTO Employee VALUES(1002,'Jack',10);
INSERT INTO Employee VALUES(1003,'Ram',20);
INSERT INTO Employee VALUES(1004,'Sita',20);

COMMIT;

SELECT * FROM Employee;


