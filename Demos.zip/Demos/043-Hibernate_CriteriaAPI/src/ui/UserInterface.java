package ui;

import java.util.List;

import resources.AppConfig;
import resources.HibernateUtility;
import bean.Employee;
import dao.EmployeeDAO;

public class UserInterface {

	public static void criteriaRestrictions() {
		List<Employee> empDetails = null;
		try {
			EmployeeDAO dao=new EmployeeDAO();
			empDetails = dao.criteriaRestrictions();
			System.out.println("List of Employees ");
			System.out.println("==================");
			System.out.println("Employee Id\t\tEmployee Name\t\tDeptCode  ");
			System.out
					.println("================================================================");
			for (Employee employee : empDetails) {
				System.out.println(employee.getEmpId() + "\t\t\t"
						+ employee.getName() + "\t\t\t"
						+ employee.getDeptCode() + "\t\t\t");
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void criteriaInterface() {
		List<Employee> empDetails = null;
		try {
			EmployeeDAO dao = new EmployeeDAO();
			empDetails = dao.criteriaInterface();
			System.out.println("List of Employees ");
			System.out.println("==================");
			System.out.println("Employee Id\t\tEmployee Name\t\tDeptCode  ");
			System.out
					.println("================================================================");
			for (Employee employee : empDetails) {
				System.out.println(employee.getEmpId() + "\t\t\t"
						+ employee.getName() + "\t\t\t"
						+ employee.getDeptCode() + "\t\t\t");
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void criteriaOrder() {
		List<Employee> empDetails = null;
		try {
			EmployeeDAO dao = new EmployeeDAO();
			empDetails = dao.criteriaOrder();
			System.out.println("List of Employees ");
			System.out.println("==================");
			System.out.println("Employee Id\t\tEmployee Name\t\tDeptCode  ");
			System.out
					.println("================================================================");
			for (Employee employee : empDetails) {
				System.out.println(employee.getEmpId() + "\t\t\t"
						+ employee.getName() + "\t\t\t"
						+ employee.getDeptCode() + "\t\t\t");
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void main(String args[]) {
		try{
			//criteriaInterface();
			//criteriaRestrictions();
			criteriaOrder();
		}finally{
			HibernateUtility.closeSessionFactory();
		}

	}
}
