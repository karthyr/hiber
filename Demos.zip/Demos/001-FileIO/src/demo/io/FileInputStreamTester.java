package demo.io;

import java.io.FileInputStream;
import java.io.IOException;

public class FileInputStreamTester {

	public static void main(String[] args) {
		
		
		try (FileInputStream fis = new FileInputStream("resources/Data.dat")) // provide the location of the file; from which data has to be read
		{	
			System.out.println("Data in the file is:");
			
		
			int i = fis.read();		// Reads a byte of data from the input stream. 
								// read() returns the next byte of data, or -1 if the end of the file is reached
			
			while (i != -1) 		// Terminating condition : checking if end of file is reached
			{ 		
				System.out.print((byte)i+" "); 	// printing the byte data in the console
				i = fis.read();
			}
		} 
		catch (IOException ioe) {
			System.err.println("Error :"+ioe.getMessage());
		}
	}
}
