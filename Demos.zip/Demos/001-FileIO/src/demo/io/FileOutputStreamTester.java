package demo.io;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamTester {

	public static void main(String[] args) {
		
		try (FileOutputStream fos = new FileOutputStream("resources/Data.dat")) // provide the location of the file; to which data has to be written
		
		{	
			// write() Writes the specified byte to the output stream
			
				fos.write(68);
				fos.write(32);
				fos.write(69);
				fos.write(32);
				fos.write(70);
				fos.write(32);

			System.out.println("Data written successfully");

		} 
		
		catch (IOException ioe) {
			System.err.println("Error :"+ioe.getMessage());
			
		}
	}

}
