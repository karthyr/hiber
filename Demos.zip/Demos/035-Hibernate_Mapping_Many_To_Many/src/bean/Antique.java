package bean;

public class Antique {
	private Integer antiqueId;
	private String antiqueName;
	private Integer price;

	public Integer getAntiqueId() {
		return antiqueId;
	}

	public void setAntiqueId(Integer antiqueId) {
		this.antiqueId = antiqueId;
	}

	public String getAntiqueName() {
		return antiqueName;
	}

	public void setAntiqueName(String antiqueName) {
		this.antiqueName = antiqueName;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

}
