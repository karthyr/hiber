package ui;

import java.util.ArrayList;
import java.util.List;

import resources.AppConfig;
import resources.HibernateUtility;
import dao.CustomerDAO;

public class UserInterface {

	public static void main(String[] args) {
		try {
			registerAntique();
		} finally {
			HibernateUtility.closeSessionFactory();
		}
	}

	public static void registerAntique() {
		CustomerDAO dao = new CustomerDAO();
		Integer customerId = null;
		try {

			List<Integer> antiqueIds = new ArrayList<Integer>();
			antiqueIds.add(5002);
			antiqueIds.add(5004);

			customerId = 1002;
			dao.registerAntique(customerId, antiqueIds);

			System.out
					.println("-------------------------------------------------------------");
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.SUCCESS") + ": " + customerId);
			System.out
					.println("-------------------------------------------------------------");

		} catch (Exception e) {

			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}

	}
}
