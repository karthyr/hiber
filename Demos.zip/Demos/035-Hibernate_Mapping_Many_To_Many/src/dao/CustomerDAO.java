package dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import entity.AntiqueEntity;
import entity.CustomerEntity;

public class CustomerDAO{

	

	public void registerAntique(Integer customerId, List<Integer> antiqueIds)
			throws Exception {

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		CustomerEntity customerEntity = null;
		AntiqueEntity antiqueEntity = null;

		List<AntiqueEntity> register = new ArrayList<AntiqueEntity>();

		Session session = null;
		try {

			session = sessionFactory.openSession();

			customerEntity = (CustomerEntity) session.get(CustomerEntity.class,customerId);
			
			if (customerEntity != null)
				for (Integer value : antiqueIds) {
					antiqueEntity = (AntiqueEntity) session.get(AntiqueEntity.class, value);

					register.add(antiqueEntity);

				}

			session.beginTransaction();
			customerEntity.setAntiques(register);
			session.getTransaction().commit();

		} catch (Exception exception) {

			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(CustomerDAO.class);
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHINCAL_ERROR", exception);
		} finally {
			if( session.isOpen() || session!=null){
				session.close();
			}
		}
	}

}