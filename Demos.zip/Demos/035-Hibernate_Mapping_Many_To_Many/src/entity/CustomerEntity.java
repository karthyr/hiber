package entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "antiqueshop_customer")
public class CustomerEntity {

	@Id
	private Integer customerId;
	private String customerName;
	
	
	@ManyToMany(cascade = CascadeType.ALL)
	
	// Creating a Third Table in the Database 
	@JoinTable(name = "antiqueshop_antiqueCustomer", 
	
	// joinColumns and inverseJoinColumns for referring the linking columns in both the tables.
	
	joinColumns = @JoinColumn(name = "customerId", referencedColumnName = "customerId"), 
	inverseJoinColumns = @JoinColumn(name = "antiqueId", referencedColumnName = "antiqueId"))
	
	//Creating an instance of Target Entity
	private List<AntiqueEntity> antiques;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public List<AntiqueEntity> getAntiques() {
		return antiques;
	}

	public void setAntiques(List<AntiqueEntity> antiques) {
		this.antiques = antiques;
	}

}
