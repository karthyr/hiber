DROP TABLE antiqueshop_customer CASCADE CONSTRAINTS;
DROP TABLE antiqueshop_antique CASCADE CONSTRAINTS;
DROP TABLE antiqueshop_antiqueCustomer CASCADE CONSTRAINTS;

DROP SEQUENCE hibernate_sequence;

CREATE SEQUENCE hibernate_sequence start with 1004;

CREATE TABLE antiqueshop_customer(
customerId number(6) CONSTRAINT antiqueshop_customerPK PRIMARY KEY,
customerName varchar2(30) CONSTRAINT antiqueshop_customerName NOT NULL);


CREATE TABLE antiqueshop_antique(
antiqueId number(6) CONSTRAINT antiqueshop_antiquePK PRIMARY KEY,
antiqueName varchar2(30) CONSTRAINT antiqueshop_antiqueName NOT NULL,
price number(5) CONSTRAINT antiqueshop_antiquePrice NOT NULL);

CREATE TABLE antiqueshop_antiqueCustomer(
customerId number(6) CONSTRAINT antiqueshop_bookauthorFK1 REFERENCES antiqueshop_customer(customerId),
antiqueId number(6) CONSTRAINT antiqueshop_bookauthorFK2 REFERENCES antiqueshop_antique(antiqueId),
CONSTRAINT antiqueshop_antiqueCustomerPK PRIMARY KEY(customerId,antiqueId));

INSERT INTO antiqueshop_customer VALUES(1001,'Lisa');
INSERT INTO antiqueshop_customer VALUES(1002,'Johan');
INSERT INTO antiqueshop_customer VALUES(1003,'Katherine');

INSERT INTO antiqueshop_antique VALUES(5001,'Clay Model',2000.0);
INSERT INTO antiqueshop_antique VALUES(5003,'Silver Coin',3000.0);
INSERT INTO antiqueshop_antique VALUES(5004,'Krishna Key',3000.0);

INSERT INTO antiqueshop_antiqueCustomer VALUES(1001,5003);
INSERT INTO antiqueshop_antiqueCustomer VALUES(1001,5001);

select * from  antiqueshop_customer;
select * from antiqueshop_antique;
select * from antiqueshop_antiqueCustomer;

