package ui;

import dao.StudentDAO;

public class UserInterface {

	public static void main(String args[]) {

		try {
			int count = new StudentDAO().addStudent();
			System.out.println(count + " student registered successfully");
		} catch (Exception exception) {
			System.err.println("ERROR: "+exception.getMessage());
		}
	}
}
