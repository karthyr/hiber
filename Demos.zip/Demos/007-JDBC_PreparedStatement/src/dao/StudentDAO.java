package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StudentDAO {

	public Integer addStudent() throws Exception {
		int count = 0;

		// SQL statement to be compiled and reused
		String sql = "insert into student values(?,?)";

		// Creating Connection and PreparedStatment instance
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:system/oracle@localhost:1521:xe");
				PreparedStatement pStatement = connection.prepareStatement(sql)) 
		{

			// Setting the parameters for the query
			pStatement.setInt(1, 1010);
			pStatement.setString(2,"Sana");

			// Executing the statement
			count = pStatement.executeUpdate();

		} catch (SQLException exception) {
			throw exception;
		} catch (Exception exception) {
			throw exception;
		}
		return count;
	}

}
