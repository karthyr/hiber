Drop table student cascade constraints;

create table student (
studentid number(6) CONSTRAINT stud_pk primary key,
studentname VARCHAR2(25)
);

insert into student values(1001,'Rakesh');
insert into student values(1002,'Biresh');
insert into student values(1003,'Rupali');

select * from student;