package bean;

import java.util.Calendar;

/**
 * Bean class to pass Product details across different tiers
 * @author ETA
 */
public class Product {

	private Long productId;
	private String productName;
	private Double price;
	private Calendar manufactureDate;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Calendar getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(Calendar manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

}
