package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import bean.Product;
import entity.ProductEntity;

public class ProductDAO {

	/**
	 * Adds a product record to database
	 * populates ProductEntity with the Product object given, and persists the same to database
	 * @param product
	 * @return productId of the product persisted
	 * @throws Exception
	 */
	public Long addProduct(Product product) throws Exception {

		EntityManagerFactory entityManagerFactory=null;
		EntityManager entityManager = null;
		ProductEntity productEntity = null;
		try {
			// Creating EntityManageFactory using same persistence unit name mentioned in persistence.xml
			entityManagerFactory=Persistence.createEntityManagerFactory("Demo");

			// Creating Entity Manager
			entityManager = entityManagerFactory.createEntityManager();

			// Creating and Populating the ProductEntity instance
			productEntity=new ProductEntity();
			productEntity.setProductId(product.getProductId());
			productEntity.setProductName(product.getProductName());
			productEntity.setPrice(product.getPrice());
			productEntity.setManufactureDate(product.getManufactureDate());

			// Making a transaction Object
			EntityTransaction entityTransaction = entityManager.getTransaction();

			// Beginning the transaction
			entityTransaction.begin();

			// scheduling the persistence of the userEntity
			entityManager.persist(productEntity);

			// Transaction completion is done using this statement and all the scheduled database updates will be reflected 
			entityTransaction.commit();

		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
			if (entityManagerFactory != null) {
				entityManagerFactory.close();
			}
		}
		return productEntity.getProductId();

	}

}
