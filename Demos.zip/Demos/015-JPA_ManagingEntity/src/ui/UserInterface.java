package ui;

import java.util.Calendar;

import resources.AppConfig;
import bean.Product;
import dao.ProductDAO;


public class UserInterface {
	
	public static void addProduct()throws Exception {
		try {
			
			Product product=new Product();
			//set unique ProductId
			product.setProductId(1006l);
			product.setProductName("Clay model");
			Calendar manufactureDate = Calendar.getInstance();
			manufactureDate.set(2013, 04, 06);
			product.setManufactureDate(manufactureDate);
			product.setPrice(500.0d);
			
			ProductDAO dao=new ProductDAO();
			Long productId=dao.addProduct(product);
			
			System.out.println(AppConfig.PROPERTIES.getProperty("UserInterface.ADD_SUCCESS")+productId);
		} 
		catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
		System.out.println("\n\n");
	}
	public static void main(String args[]) throws Exception 
	{
		addProduct();
	}
	
}
