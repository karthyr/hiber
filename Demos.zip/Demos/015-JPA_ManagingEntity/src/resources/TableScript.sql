Drop table Product cascade constraints;

create table Product(
PRODUCTID NUMBER(10) CONSTRAINT product_productid_pk primary key,
NAME VARCHAR2(200),
MANUFACTUREDATE Date
);


insert into  Product  values('1001', 'Mobile','10-FEB-2005');
insert into  Product  values('1002', 'WashingMachine','05-MAR-1998');
insert into  Product  values('1003', 'Oven','09-JUN-2008');
insert into  Product  values('1004', 'Television','02-Jan-2012');
insert into  Product  values('1005', 'Watch','17-MAY-2011');

select * from Product;

