package entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


/**
 * Entity class to hold product data  
 * @author ETA
 */
@Entity 
@Table(name = "Product") // Specify the name of the table in database 
public class ProductEntity {    
	
	@Id //identifier for the entity
	private Long productId;
	
	@Column(name="name") // specifies the details of the database column corresponding to for this attribute
	private String productName;
	
	@Temporal(TemporalType.DATE) // 
	private Calendar manufactureDate;
	
	@Transient // attributes whose values are not stored in the database
	private Double price;
	
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setManufactureDate(Calendar manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	public Calendar getManufactureDate() {
		return manufactureDate;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	

	
}
