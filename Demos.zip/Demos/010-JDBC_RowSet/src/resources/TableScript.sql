DROP TABLE customer cascade constraints;

CREATE TABLE customer
(customerId NUMBER(4) primary key,
customerName VARCHAR2(10),
emailId VARCHAR2(20));

INSERT INTO customer VALUES(1001,'Jack','jack123@infy.com');
INSERT INTO customer VALUES(1002,'Jill','jill123@infy.com');
INSERT INTO customer VALUES(1003,'John','john123@infy.com');
INSERT INTO customer VALUES(1004,'Jerry','jerry123@infy.com');

commit;

select * from customer;
