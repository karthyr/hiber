package demo;

import javax.sql.RowSetEvent;
import javax.sql.RowSetListener;

public class DemoListener implements RowSetListener {

	@Override
	public void rowSetChanged(RowSetEvent event) {
		System.out.println("LISTNER : RowSet object in the given RowSetEvent object has changed its entire contents. ");
		System.out.println("------------------------------------------");
	}

	@Override
	public void rowChanged(RowSetEvent event) {
		System.out.println("LISTNER : RowSet object has had a change in one of its rows");
		System.out.println("------------------------------------------");
	}

	@Override
	public void cursorMoved(RowSetEvent event) {
		System.out.println("LISTNER : RowSet object's cursor has moved");
		System.out.println("------------------------------------------");
		
	}

}
