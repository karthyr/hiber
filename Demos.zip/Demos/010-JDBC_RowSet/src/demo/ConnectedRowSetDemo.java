package demo;



import java.sql.SQLException;

import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;

public class ConnectedRowSetDemo {

	public static void main(String[] args) {
		try {
			//getRowData();
			//addRowData();
			//deleteAllData();
		} catch (Exception e) {
			System.err.println("ERROR: "+e.getMessage());
		}
	}
	public static void addRowData() throws Exception {
		RowSetFactory factory=null;
		JdbcRowSet jdbcRowSet=null;

		//cannot use try with resource here since RowSetFactory is not auto closeable
		try
		{
			factory=RowSetProvider.newFactory();
			jdbcRowSet = factory.createJdbcRowSet();

			jdbcRowSet.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
			jdbcRowSet.setUsername("system");
			jdbcRowSet.setPassword("oracle");

			jdbcRowSet.setCommand("insert into customer values('1005','Aldrin','buzz@infy.com')");
			jdbcRowSet.execute();
			jdbcRowSet.addRowSetListener(new DemoListener());
			
			System.out.println("Data inserted Successfully");
		}
		catch(SQLException se){
			System.err.println("ERROR: "+se.getMessage());
		}
		catch (Exception e) {
			System.err.println("ERROR: "+e.getMessage());
		}finally{
			if(jdbcRowSet!=null){
				jdbcRowSet.close();
			}
		}
	}

		public static void deleteAllData() throws Exception {
			RowSetFactory factory=null;
			JdbcRowSet jdbcRowSet=null;

			//cannot use try with resource here since RowSetFactory is not auto closeable
			try
			{
				factory=RowSetProvider.newFactory();
				jdbcRowSet = factory.createJdbcRowSet();

				jdbcRowSet.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
				jdbcRowSet.setUsername("system");
				jdbcRowSet.setPassword("oracle");

				// Read Only
				//jdbcRowSet.setCommand("select * from customer");
				
				// Updatable
				jdbcRowSet.setCommand("select customerId,customerName from customer");
				
				jdbcRowSet.execute();
				jdbcRowSet.addRowSetListener(new DemoListener());
				
				jdbcRowSet.next();
				System.out.println("-------------------------------------------");
				System.out.println("Customer ID :"+jdbcRowSet.getInt("customerId"));
				System.out.println("Name :"+jdbcRowSet.getString("customerName"));
				System.out.println("-------------------------------------------");
				
				jdbcRowSet.deleteRow();
				System.out.println("Data deleted Successfully");
				
			}
			catch(SQLException se){
				System.err.println("ERROR: "+se.getMessage());
			}
			catch (Exception e) {
				System.err.println("ERROR: "+e.getMessage());
			}finally{
				if(jdbcRowSet!=null){
					jdbcRowSet.close();
				}
			}
		
	}
	public static void getRowData() throws SQLException   {

		RowSetFactory factory=null;
		JdbcRowSet jdbcRowSet=null;

		//cannot use try with resource here since RowSetFactory is not auto closeable
		try
		{
			factory=RowSetProvider.newFactory();
			jdbcRowSet = factory.createJdbcRowSet();

			jdbcRowSet.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
			jdbcRowSet.setUsername("system");
			jdbcRowSet.setPassword("oracle");

			jdbcRowSet.setCommand("select * from Customer");
			jdbcRowSet.execute();
			jdbcRowSet.addRowSetListener(new DemoListener());
			
			System.out.println("Customer Details :");
			// Going in forward direction
			/*while(jdbcRowSet.next()){
			System.out.println("-------------------------------------------");
			System.out.println("Customer ID :"+jdbcRowSet.getInt(1));
			System.out.println("Name :"+jdbcRowSet.getString(2));
			System.out.println("Email :"+jdbcRowSet.getString(3));
			System.out.println("-------------------------------------------");
			}*/
			
			// Going in reverse direction
			/*jdbcRowSet.afterLast();
			while(jdbcRowSet.previous()){
				System.out.println("-------------------------------------------");
				System.out.println("Customer ID :"+jdbcRowSet.getInt(1));
				System.out.println("Name :"+jdbcRowSet.getString(2));
				System.out.println("Email :"+jdbcRowSet.getString(3));
				System.out.println("-------------------------------------------");
			}*/
			
			// Reaching a random position
			/*if(jdbcRowSet.absolute(2)){
				System.out.println("-------------------------------------------");
				System.out.println("Customer ID :"+jdbcRowSet.getInt(1));
				System.out.println("Name :"+jdbcRowSet.getString(2));
				System.out.println("Email :"+jdbcRowSet.getString(3));
				System.out.println("-------------------------------------------");
			}*/
			
		}
		catch(SQLException se){
			System.err.println("ERROR: "+se.getMessage());
		}
		catch (Exception e) {
			System.err.println("ERROR: "+e.getMessage());
		}finally{
			if(jdbcRowSet!=null){
				jdbcRowSet.close();
			}
		}

	}
}


