Drop table Student cascade constraints;
Drop table Course cascade constraints;

CREATE TABLE Course(
COURSEID        VARCHAR2(20) CONSTRAINT course_courseid_pk primary key,
COURSENAME      VARCHAR2(200),
DURATION NUMBER
);

CREATE TABLE Student(
STUDENTID NUMBER CONSTRAINT studentid_pk primary key, 
STUDENTNAME VARCHAR2(30),
COURSEID VARCHAR2(255) CONSTRAINT courseid_fk references Course(courseid)
);


--Insert scripts
insert into Course values('J-101','JAVA POJO',30);
insert into Course values('J-102','HIBERNATE',25);
insert into Course values('J-103','JSF',30);

insert into Student values('1101','Scott','J-102');
insert into Student values('1102','Gary','J-102');
 
SELECT * FROM Student;
SELECT * FROM Course;