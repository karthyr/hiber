package ui;

import resources.AppConfig;
import resources.HibernateUtility;
import bean.Student;
import dao.StudentCourseDAO;

public class UserInterface {
	public static void main(String[] args) {
		try{
		//addStudent();
		//getStudentDetails();
		//updateStudent();
		}
		finally{
			 HibernateUtility.closeSessionFactory();
		 }
	}

	public static void updateStudent() {
		try {
			Integer studentId = 1101;
			String courseId = "J-101";
			StudentCourseDAO dao=new StudentCourseDAO();
			dao.updateStudent(studentId,courseId);
			System.out.println(AppConfig.PROPERTIES	.getProperty("UserInterface.UPDATE_SUCCESS"));
			
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}

	}

	public static void getStudentDetails() {
		try {
			StudentCourseDAO dao=new StudentCourseDAO();
			Student student = dao.getDetails(1102);
			System.out.println("-------------------Student Details---------------------");
			System.out.println("Student Name:" + student.getStudentName());
			System.out.println("Student Id:" + student.getStudentId());
			System.out.println();
			System.out.println("------------------Course Details-----------------------");
			System.out
					.println("Course Id:" + student.getCourse().getCourseId());
			System.out.println("Course Name:"
					+ student.getCourse().getCourseName());
			System.out.println("Duration:" + student.getCourse().getDuration());
			
			System.out.println("---------------------------------------------------------");
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));

		}
	}

	public static void addStudent() {
		try {
			StudentCourseDAO dao=new StudentCourseDAO();
			Student student = new Student();
			student.setStudentId(1104);
			student.setStudentName("RAM");
			String courseId = "J-102";
			dao.addStudent(student, courseId);
			String message = AppConfig.PROPERTIES.getProperty("UserInterface.INSERT_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

}
