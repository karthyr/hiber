package dao;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Course;
import bean.Student;
import entity.CourseEntity;
import entity.StudentEntity;

public class StudentCourseDAO {

	/*
	 * This method is to get the details of student along with the course
	 * details and return the student bean
	 */
	public Student getDetails(Integer studentId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Student student = null;
		Session session = null;
		try {
			
			session = sessionFactory.openSession();
			
			session.getTransaction().begin();

			// get the student entity
			StudentEntity studentEntity = (StudentEntity) session.get(StudentEntity.class, studentId);

			// populate the student using student entity
			if (studentEntity != null) {
				
				student = new Student();
					student.setStudentName(studentEntity.getStudentName());
					student.setStudentId(studentEntity.getStudentId());
					
					Course course = new Course();
					
					course.setCourseId(studentEntity.getCourse().getCourseId());
					course.setCourseName(studentEntity.getCourse().getCourseName());
					course.setDuration(studentEntity.getCourse().getDuration());
				
					student.setCourse(course);
			}
			session.getTransaction().commit();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return student;

	}

	/*
	 * This method is to add the student to the database along with course
	 */
	public void addStudent(Student student, String courseId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		
		try {
			session = sessionFactory.openSession();
			
			StudentEntity studentEntity = new StudentEntity();
			
			CourseEntity courseEntity = (CourseEntity) session.get(	CourseEntity.class, courseId);
			
			if (courseEntity != null) {
				studentEntity.setCourse(courseEntity);
				studentEntity.setStudentId(student.getStudentId());
				studentEntity.setStudentName(student.getStudentName());
			}

			session.getTransaction().begin();
			session.persist(studentEntity);
			session.getTransaction().commit();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
	}

	/* This method is to update the course details of a student */
	public void updateStudent(Integer studentId, String courseId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			StudentEntity studentEntity = (StudentEntity) session.get(StudentEntity.class,studentId);
			CourseEntity courseEntity = (CourseEntity) session.get(CourseEntity.class,courseId);
			
			if (studentEntity != null && courseEntity!=null) {
				// update the course details
				
				session.getTransaction().begin();
				studentEntity.setCourse(courseEntity);
				session.getTransaction().commit();
			}

		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
	}

}
