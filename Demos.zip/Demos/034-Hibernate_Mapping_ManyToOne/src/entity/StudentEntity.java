package entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Student")
public class StudentEntity {
	@Id
	private Integer studentId;
	private String studentName;
	/*
	 * cascadeType.ALL means all the persistence operations done on the parent will
	 * be passed to the child.
	 */
	
	@ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="courseId")
	private CourseEntity course;

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public CourseEntity getCourse() {
		return course;
	}

	public void setCourse(CourseEntity course) {
		this.course = course;
	}

}
