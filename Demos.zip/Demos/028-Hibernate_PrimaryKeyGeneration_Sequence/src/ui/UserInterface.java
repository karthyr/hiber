package ui;

import resources.AppConfig;
import resources.HibernateUtility;
import bean.Employee;
import dao.EmployeeDAO;

public class UserInterface {

	public static void addEmployee() {
		try {
			Employee employee = new Employee();
			
			employee.setEmployeeName("Clark");
			employee.setBasicSalary(10600.00);
			employee.setAllowances(12000.00);

			EmployeeDAO dao = new EmployeeDAO();
			Integer id=dao.addEmployee(employee);

			String message = AppConfig.PROPERTIES.getProperty("UserInterface.NEW_EMPLOYEE_SUCCESS");
			System.out.println(message+id);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	
	public static void main(String args[]) {

		try {
			 addEmployee();
		} finally {
			HibernateUtility.closeSessionFactory();
		}

	}
}
