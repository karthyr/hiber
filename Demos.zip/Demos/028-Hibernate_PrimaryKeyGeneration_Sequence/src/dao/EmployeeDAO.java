package dao;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Employee;
import entity.EmployeeEntity;

public class EmployeeDAO {
	/**
	 * Inserts a new employee into the database
	 * 
	 * @param employeeTO
	 *            - employee details
	 * @throws Exception
	 */
	public Integer addEmployee(Employee employee) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		Integer employeeId=null;
		try {

			session = sessionFactory.openSession();

			EmployeeEntity empEntity = new EmployeeEntity();
			empEntity.setEmployeeName(employee.getEmployeeName());
			empEntity.setBasicSalary(employee.getBasicSalary());
			empEntity.setAllowances(employee.getAllowances());

			session.beginTransaction();
			employeeId=(Integer) session.save(empEntity);
			session.getTransaction().commit();
		
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return employeeId;
	}
}
