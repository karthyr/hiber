package ui;

import resources.AppConfig;
import bean.Employee;
import dao.LifeCycleAnnotationsDAO;

public class UserInterface {
	
	public static void addEmployee() {
		try {
			Employee employee = new Employee();
			
			employee.setEmpId(1234);
			employee.setName("Jim");
			employee.setBasicSalary(10600.00);
			employee.setAllowances(12000.00);
			
			LifeCycleAnnotationsDAO dao=new LifeCycleAnnotationsDAO();
			dao.addEmployee(employee);
			
			String message = AppConfig.PROPERTIES.getProperty("UserInterface.NEW_EMPLOYEE_SUCCESS");
			System.out.println(message);
		}
		catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	public static void main(String args[]){
		 	addEmployee();
	}
}
