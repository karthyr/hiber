package entity;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="LifeCycleAnnotations_Employee")
@EntityListeners(EmployeeListener.class)
public class EmployeeEntity {
	@Id
	private Integer empId;
	private String name;
	private Double basicSalary;
	private Double allowances;
	
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(Double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public Double getAllowances() {
		return allowances;
	}
	public void setAllowances(Double allowances) {
		this.allowances = allowances;
	}
}
