package entity;

import javax.persistence.PostPersist;
import javax.persistence.PrePersist;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class EmployeeListener {

	//Entity Life Cycle Annotations Starts here
		@PrePersist
		void prePersistLog(EmployeeEntity entity){
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.info("PrePersist:A new entity instance will be inserted into employee table");
		}
		@PostPersist
		void postPersistLog(EmployeeEntity entity) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.info("PostPersist:A new entity instance is successfully inserted into employee table");
		}
		
		
}
