DROP TABLE LifeCycleAnnotations_Employee cascade constraints;

CREATE TABLE LifeCycleAnnotations_Employee(EmpId number(7) CONSTRAINT LCA_EmpPK PRIMARY KEY,
Name varchar2(25) CONSTRAINT LCA_EName_Nnull NOT NULL,
BasicSalary Number(10,2) CONSTRAINT LCA_BS_Nnull NOT NULL
CONSTRAINT LCA_BS_Check CHECK(BasicSalary > 0),
Allowances Number(10,2) CONSTRAINT LCA_Allowances_Nnull NOT NULL
CONSTRAINT LCA_Allowances_Check CHECK(Allowances > 0));

INSERT INTO LifeCycleAnnotations_Employee VALUES(1001,'Scott', 25000,4000);
INSERT INTO LifeCycleAnnotations_Employee VALUES(1002,'Jack',30000,3000);
INSERT INTO LifeCycleAnnotations_Employee VALUES(1003,'Ram',26000,5000);
INSERT INTO LifeCycleAnnotations_Employee VALUES(1004,'Sita',12500,5000);

SELECT * FROM LifeCycleAnnotations_Employee;




