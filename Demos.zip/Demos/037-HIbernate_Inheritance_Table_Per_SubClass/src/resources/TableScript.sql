DROP TABLE Joined_Employee CASCADE CONSTRAINTS;
DROP TABLE Joined_PermanentEmployee CASCADE CONSTRAINTS;
DROP TABLE Joined_ContractEmployee CASCADE CONSTRAINTS;

CREATE TABLE Joined_employee(
EmpId number(7) CONSTRAINT Join_EmpPK PRIMARY KEY,
Name varchar2(25) CONSTRAINT Join_Emp_Nnull NOT NULL
);

CREATE TABLE Joined_PermanentEmployee(
EmpId number(7) CONSTRAINT Join_PEmpPK PRIMARY KEY
CONSTRAINT Join_PEFK REFERENCES Joined_employee(EmpId),
BasicSalary number(10,2) CONSTRAINT Join_BSal_Nnull NOT NULL 
CONSTRAINT Join_BSal_Check CHECK(BasicSalary > 0),
Allowances number(10,2) CONSTRAINT Join_Allowances_Nnull NOT NULL, 
CONSTRAINT Join_Allowances_Check CHECK(Allowances > 0)
);


CREATE TABLE Joined_ContractEmployee(
EmpId number(7) CONSTRAINT Join_ConEmpPK PRIMARY KEY
CONSTRAINT Join_ConEmpFK REFERENCES Joined_employee(EmpId),
AreaOfSpecialization varchar2(15) CONSTRAINT Join_AOfSNnull NOT NULL,
ProfessionalCharges number(10,2) CONSTRAINT Join_PCNnull NOT NULL
CONSTRAINT Join_Rph_Check CHECK(ProfessionalCharges > 0)
);


INSERT INTO Joined_employee VALUES(1001,'Scott');
INSERT INTO Joined_employee VALUES(4001,'Jack');
COMMIT;

INSERT INTO Joined_PermanentEmployee VALUES(1001,15000,4500);
INSERT INTO Joined_ContractEmployee VALUES(4001,'Architecture',5000);
COMMIT;

SELECT * from Joined_Employee;
SELECT * from Joined_PermanentEmployee;
SELECT * from Joined_ContractEmployee;
