package entity;


import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Joined_PermanentEmployee")

public class PermanentEmployeeEntity extends EmployeeEntity {
	private Double basicSalary;
	private Double allowances;
	
	public Double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(Double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public Double getAllowances() {
		return allowances;
	}
	public void setAllowances(Double allowances) {
		this.allowances = allowances;
	}
}
