package entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Joined_ContractEmployee")
public class ContractEmployeeEntity extends EmployeeEntity {
	private Double professionalCharges;
	private String areaOfSpecialization;

	public Double getProfessionalCharges() {
		return professionalCharges;
	}

	public void setProfessionalCharges(Double professionalCharges) {
		this.professionalCharges = professionalCharges;
	}

	public String getAreaOfSpecialization() {
		return areaOfSpecialization;
	}

	public void setAreaOfSpecialization(String areaOfSpecialization) {
		this.areaOfSpecialization = areaOfSpecialization;
	}

}
