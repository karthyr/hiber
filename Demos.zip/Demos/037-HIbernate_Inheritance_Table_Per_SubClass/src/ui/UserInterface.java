package ui;

import resources.AppConfig;
import resources.HibernateUtility;
import bean.ContractEmployee;
import bean.Employee;
import bean.PermanentEmployee;
import dao.EmployeeInheritanceDAO;

public class UserInterface {
	public static void addPermanentEmployee(Integer empId, String name,
			Double basicSalary, Double allowances) {
		try {
			PermanentEmployee permanentEmployee = new PermanentEmployee();
			permanentEmployee.setEmpId(empId);
			permanentEmployee.setName(name);
			permanentEmployee.setBasicSalary(basicSalary);
			permanentEmployee.setAllowances(allowances);

			EmployeeInheritanceDAO dao=new EmployeeInheritanceDAO();
			dao.addEmployee(permanentEmployee);

			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.NEW_EMPLOYEE_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void addContractEmployee(Integer empId, String name,
			String areaOfSpecialization, Double professionalCharges) {
		try {
			ContractEmployee contractEmployee = new ContractEmployee();
			contractEmployee.setEmpId(empId);
			contractEmployee.setName(name);
			contractEmployee.setAreaOfSpecialization(areaOfSpecialization);
			contractEmployee.setProfessionalCharges(professionalCharges);

			EmployeeInheritanceDAO dao=new EmployeeInheritanceDAO();
			dao.addEmployee(contractEmployee);

			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.NEW_EMPLOYEE_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getEmployeeDetails(Integer employeeId) {
		try {
			EmployeeInheritanceDAO dao=new EmployeeInheritanceDAO();
		
			Employee employee = 	dao.getEmployeeDetails(employeeId);
			System.out.println("Employee Name: " + employee.getName());
			if (employee instanceof PermanentEmployee) {
				PermanentEmployee permanentEmployee = (PermanentEmployee) employee;

				System.out.println("Basic Salary: "
						+ permanentEmployee.getBasicSalary());
				System.out.println("Allowances: "
						+ permanentEmployee.getAllowances());
			}
			if (employee instanceof ContractEmployee) {
				ContractEmployee contractEmployee = (ContractEmployee) employee;

				System.out.println("Area of Specialization: "
						+ contractEmployee.getAreaOfSpecialization());
				System.out.println("Professional Charges: "
						+ contractEmployee.getProfessionalCharges());
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}

	}

	public static void main(String args[]) {

		try{
			 	//addPermanentEmployee(1006,"Mrudhu",6700.00,2000.00);
				//addContractEmployee(400,"Mahi","Testing",10000.00);
				//getEmployeeDetails(1001);
				
		}finally{
			HibernateUtility.closeSessionFactory();
		}
	}
}
