package dao;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.ContractEmployee;
import bean.Employee;
import bean.PermanentEmployee;
import entity.ContractEmployeeEntity;
import entity.EmployeeEntity;
import entity.PermanentEmployeeEntity;

public class EmployeeInheritanceDAO{

	/**
	 * Add New employee details to the database
	 * 
	 * @param employee
	 * @throws Exception
	 *             if there is a technical error
	 */
	public void addEmployee(Employee employee) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		try {
			
			if (employee instanceof PermanentEmployee) {
				PermanentEmployee permanentEmployee = (PermanentEmployee) employee;
				PermanentEmployeeEntity permanentEmployeeEntity = new PermanentEmployeeEntity();
				permanentEmployeeEntity.setAllowances(permanentEmployee
						.getAllowances());
				permanentEmployeeEntity.setBasicSalary(permanentEmployee
						.getBasicSalary());
				permanentEmployeeEntity.setEmpId(permanentEmployee.getEmpId());
				permanentEmployeeEntity.setName(permanentEmployee.getName());
				session.getTransaction().begin();
				session.persist(permanentEmployeeEntity);
				session.getTransaction().commit();
			}
			if (employee instanceof ContractEmployee) {
				ContractEmployee contractEmployee = (ContractEmployee) employee;
				ContractEmployeeEntity contractEmployeeEntity = new ContractEmployeeEntity();
				contractEmployeeEntity.setAreaOfSpecialization(contractEmployee
						.getAreaOfSpecialization());
				contractEmployeeEntity.setEmpId(contractEmployee.getEmpId());
				contractEmployeeEntity.setName(contractEmployee.getName());
				contractEmployeeEntity.setProfessionalCharges(contractEmployee
						.getProfessionalCharges());
				session.getTransaction().begin();
				session.persist(contractEmployeeEntity);
				session.getTransaction().commit();
			}
		
		} catch (HibernateException exception) {
		
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()||session!=null ){
				session.close();
			}
		}

	}

	/**
	 * Fetches employee details from the database
	 * 
	 * @param employeId
	 * @return Employee
	 * @throws Exception
	 *             if there is a technical error
	 */
	public Employee getEmployeeDetails(Integer employeeId) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Employee employee = null;
		Session session = sessionFactory.openSession();
		try {
			
			EmployeeEntity employeeEntity = (EmployeeEntity)session.get(EmployeeEntity.class,
					employeeId);

			if (employeeEntity instanceof PermanentEmployeeEntity) {
				//Getting Permanent Employee Details
				PermanentEmployeeEntity permanentEmployeeEntity = (PermanentEmployeeEntity) employeeEntity;
				PermanentEmployee permanentEmployee = new PermanentEmployee();
				permanentEmployee.setEmpId(permanentEmployeeEntity.getEmpId());
				permanentEmployee.setName(permanentEmployeeEntity.getName());
				permanentEmployee.setBasicSalary(permanentEmployeeEntity
						.getBasicSalary());
				permanentEmployee.setAllowances(permanentEmployeeEntity
						.getAllowances());
				employee = permanentEmployee;
			} else {
				//Getting Contract Employee Details
				ContractEmployeeEntity contractEmployeeEntity = (ContractEmployeeEntity) employeeEntity;
				ContractEmployee contractEmployee = new ContractEmployee();
				contractEmployee.setEmpId(contractEmployeeEntity.getEmpId());
				contractEmployee.setName(contractEmployeeEntity.getName());
				contractEmployee.setAreaOfSpecialization(contractEmployeeEntity
						.getAreaOfSpecialization());
				contractEmployee.setProfessionalCharges(contractEmployeeEntity
						.getProfessionalCharges());
				employee = contractEmployee;
			}
			
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()||session!=null ){
				session.close();
			}
		}
		return employee;
	}

}
