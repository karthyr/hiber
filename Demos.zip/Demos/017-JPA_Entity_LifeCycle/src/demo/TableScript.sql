drop table Employee cascade constraints;

create table Employee (
empId number(4) primary key ,
empName varchar2(20) not null ,
empLocation varchar2(50));

insert into Employee values(1001,'Scott','Mexico');
insert into Employee values(1002,'Gary','London');
insert into Employee values(1003,'Nikhil','Kolkata');

select * from employee;