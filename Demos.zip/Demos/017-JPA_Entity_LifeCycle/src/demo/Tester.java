package demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/***
 * contains() method of entity manager can be used to check whether the Entity
 * is in managed state or not. It returns true if entity is in managed state
 * other wise returns false
 ***/
public class Tester {
	
	/* start point for program */
	public static void main(String[] args) {
		/* Uncomment one at a time and try out */

		//persist();
		//find();
		//update();
		//remove();
		merge();
	}

	public static void update() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("LifeCycle");
		EntityManager em = null;
		try {
			em = emf.createEntityManager();
			System.out.println("--------------------------------------------------------");
			EmployeeEntity employee=em.find(EmployeeEntity.class, 2);
			System.out.println("After  Find   :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
			if (employee == null) {
				System.out.println("!!! Employee Record is not found in the database !!!");
			}
			else{
				System.out.println("Before Update :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
				em.getTransaction().begin();
				employee.setEmpLocation("Hyderabad");
				employee.setEmpName("Ruksar");
				System.out.println("After Update  :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
				em.getTransaction().commit();
				System.out.println("After Update  :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
			}
			System.out.println("--------------------------------------------------------");
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		} finally {
			if(em!=null){
				em.close();
			}
			if (emf != null) {
				emf.close();
				
			}
		}
	}

	public static void merge() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("LifeCycle");
		EntityManager em = null;
		try {
			em = emf.createEntityManager();
			System.out.println("--------------------------------------------------------");
			
			EmployeeEntity employee=new EmployeeEntity();
			employee.setEmpId(1002);
			//employee.setEmpId(1111);
			employee.setEmpLocation("Mysore");
			employee.setEmpName("Mahadeva");
			System.out.println("Before  merge   :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
			em.merge(employee);
			System.out.println("After   merge   :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
			
			em.getTransaction().begin();
			em.getTransaction().commit();
			System.out.println("After  Commit   :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
			System.out.println("--------------------------------------------------------");
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		} finally {
			if(em!=null){
				em.close();
			}
			if (emf != null) {
				emf.close();
				
			}
		}
	}
	
	public static void persist() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("LifeCycle");
		EntityManager em = null;
		try {
			em = emf.createEntityManager();

			System.out.println("\nEmployeeEntity instance is in NEW state");
			EmployeeEntity employee = new EmployeeEntity();

				employee.setEmpId(1);
				employee.setEmpLocation("New York");
				employee.setEmpName("Annie");
			
			em.getTransaction().begin();
			
			System.out.println("--------------------------------------------------------");
			System.out.println("Before Persist :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
			em.persist(employee);
			System.out.println("After Persist  :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
			em.getTransaction().commit();
			System.out.println("After Commit   :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));
			
			// On clearing or closing the EntityManager , the managed entities become "detached".
			em.clear();
			
			System.out.println("After Clear   :   The EmployeeEntity instance is in MANAGED state  : " + em.contains(employee));

			System.out.println("---------------------------------------------------------");

		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		} finally {
			if(em!=null){
				em.close();
			}
			if (emf != null) {
				emf.close();
				
			}
		}
	}

	public static void find() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("LifeCycle");
		EntityManager em = null;
		try {
			em = emf.createEntityManager();

			System.out.println("\nEmployeeEntity instance is in NEW state");
			EmployeeEntity employee = new EmployeeEntity();
			employee.setEmpId(1003);

			System.out.println("--------------------------------------------------------");

			System.out.println("Before Find :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(employee));

			EmployeeEntity foundEmployee = em.find(EmployeeEntity.class, employee.getEmpId());

			System.out.println("After Find :   The EmployeeEntity instance is in MANAGED state  :" + em.contains(foundEmployee));

			em.clear();
			// Returns false as the Employee Entity is in "detached" state.
			System.out.println("After Clear :  The EmployeeEntity instance is in MANAGED state  :" + em.contains(foundEmployee));
			System.out.println("--------------------------------------------------------");

		} catch (Exception exception) {
			System.out.println(exception.getMessage());

		} finally {
			if(em!=null){
				em.close();
			}
			if (emf != null) {
				emf.close();
				
			}
		}
	}

	public static void remove() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("LifeCycle");
		EntityManager em = null;
		try {
			em = emf.createEntityManager();

			System.out.println("--------------------------------------------------------");
			
			em.getTransaction().begin();
			
			EmployeeEntity employee = em.find(EmployeeEntity.class,1003);
			if (employee == null) {
				System.out.println("!!! Employee Record is not found in the database !!!");
				
			}
			else{
			System.out.println("Before Remove : The EmployeeEntity instance is in MANAGED state  :"+ em.contains(employee));
			//performing remove operation 
			em.remove(employee);

			// Returns false as the Employee Entity is in "removed" state now.
			System.out.println("After Remove :  The EmployeeEntity instance is in MANAGED state  :"+ em.contains(employee));
			
			em.getTransaction().commit();

			System.out.println("After Commit :  The EmployeeEntity instance is in MANAGED state  :"+ em.contains(employee));
			
			em.clear();
			System.out.println("After Clear  :  The EmployeeEntity instance is in MANAGED state  :" +em.contains(employee));
			
			}
			System.out.println("--------------------------------------------------------");

			

		} catch (Exception exception) {
			System.out.println(exception.getMessage());

		} finally {
			if(em!=null){
				em.close();
			}
			if (emf != null) {
				emf.close();
		
			}
		}
	}

}