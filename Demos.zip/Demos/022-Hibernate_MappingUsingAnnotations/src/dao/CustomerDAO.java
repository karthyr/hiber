package dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Customer;
import entity.CustomerEntity;

public class CustomerDAO {

	/**
	 * This method persists the Customer details given in the Customer Bean object,in to the database 
	 * @param customer
	 * @return name of the customer persisted
	 * @throws Exception
	 * @author ETA
	 */
	public String addCustomer(Customer customer) throws Exception {
		// Creating the instances of Session Factory and session
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session=null;
		CustomerEntity customerEntity = null;
		try {
			session = sessionFactory.openSession();
			// population entity object
			customerEntity = new CustomerEntity();
			customerEntity.setCustomerId(customer.getCustomerId());
			customerEntity.setEmail(customer.getEmail());
			customerEntity.setCustomerName(customer.getCustomerName());
			customerEntity.setDateOfBirth(customer.getDateOfBirth());
			customerEntity.setCity(customer.getCity());

			// Persisting the Customer Entity
			session.getTransaction().begin();
			session.persist(customerEntity);
			session.getTransaction().commit();
			
		} catch (HibernateException exception) {
			throw exception;
		} catch (Exception exception) {
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return customer.getCustomerName();
	}

}
