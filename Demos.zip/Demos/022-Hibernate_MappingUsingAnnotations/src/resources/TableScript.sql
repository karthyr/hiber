DROP TABLE Customer CASCADE CONSTRAINTS;

CREATE TABLE Customer(
id Number(5) CONSTRAINT cons_cust_Pkey PRIMARY KEY,
Name Varchar2(25) CONSTRAINT cons_cust_nnull NOT NULL,
email Varchar2(25),
dob date
);

INSERT INTO Customer VALUES(1001,'Scott','scott@infy.com','13-JUN-1991');

SELECT * from Customer;