package entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


/**
 * Customer Entity Class
 * @author ETA
 *
 */
@Entity
@Table(name = "customer")  // Providing the DB Table Name
public class CustomerEntity {
	@Id // Identifier for the Table (Primary Key)
	@Column(name = "id")
	private Integer customerId;
	
	@Column(name = "name")
	private String customerName;
	
	private String email;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "dob")
	private Calendar dateOfBirth;
	
	@Transient
	private String city;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Calendar getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Calendar dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
