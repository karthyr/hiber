package ui;

import java.util.Calendar;

import resources.HibernateUtility;
import bean.Customer;
import dao.CustomerDAO;

public class UserInterface {

	public static void main(String[] args) {
		try {
			addCustomer();
		} finally {
			HibernateUtility.closeSessionFactory();
		}
	}

	public static void addCustomer(){
		try {
			// Populating Customer Details
			Customer customer = new Customer();
			customer.setCustomerId(1002);
			customer.setCustomerName("Michael");
			Calendar dateOfBirth = Calendar.getInstance();
			dateOfBirth.set(1991, 9, 5);
			customer.setDateOfBirth(dateOfBirth);
			customer.setEmail("michael@infy.com");
			customer.setCity("London");

			// Calling the DAO method
			CustomerDAO dao = new CustomerDAO();
			String name = dao.addCustomer(customer);
			System.out.println("Customer successfully added with customer name :"+ name);
		} catch (Exception exception) {
			System.err.println("\nERROR: "+exception.getMessage());
		}

	}
}
