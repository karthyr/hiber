package dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;

import resources.HibernateUtility;
import bean.Department;
import bean.Employee;
import entity.EmployeeEntity;

@SuppressWarnings("unchecked")
public class EmployeeDepartmentDAO{

	public List<Employee> projectionsProperty() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Employee> result = null;
		try {
			// Using property method in Projections Criterion only required
			// attributes can be selected.
			Criteria criteria = session.createCriteria(EmployeeEntity.class);
			ProjectionList projList = Projections.projectionList();

			// Fetching Only the EmpId and Employee Name by setting in the
			// Projections.property
			projList.add(Projections.property("empId"));
			projList.add(Projections.property("name"));
			criteria.setProjection(projList);
			List<Object[]> empList = criteria.list();
			result = new ArrayList<Employee>();
			for (Object[] obj : empList) {
				Employee employee = new Employee();
				employee.setEmpId((Integer) obj[0]);
				employee.setName((String) obj[1]);
				result.add(employee);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return result;
	}

	public List<Employee> associations() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<EmployeeEntity> empList = null;
		List<Employee> result = null;
		try {
			Criteria criteria = session.createCriteria(EmployeeEntity.class);
			// Similar to SQL/HQL Inner Join
			Criteria crit = criteria.createCriteria("department");
			empList = crit.list();
			result = new ArrayList<Employee>();
			for (EmployeeEntity employeeEntity : empList) {
				Employee employee = new Employee();
				employee.setEmpId(employeeEntity.getEmpId());
				employee.setName(employeeEntity.getName());
				Department department = new Department();
				department.setDeptCode(employeeEntity.getDepartment()
						.getDeptCode());
				department.setDeptName(employeeEntity.getDepartment()
						.getDeptName());
				employee.setDepartment(department);
				result.add(employee);
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return result;
	}

	public List<Object[]> projectionsAggregate() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = sessionFactory.openSession();
		List<Object[]> list = null;
		try {
			Criteria criteria = session.createCriteria(EmployeeEntity.class);
			ProjectionList projList = Projections.projectionList();
			
			/*
			 * Aggregate functions can be done using Projections criterion .
			 * Some of them are given below
			 */
			projList.add(Projections.max("empId"));
			projList.add(Projections.min("empId"));
			projList.add(Projections.avg("empId"));
			projList.add(Projections.count("empId"));
			projList.add(Projections.sum("empId"));
			projList.add(Projections.countDistinct("name"));
			projList.add(Projections.rowCount());
			criteria.setProjection(projList);
			list = criteria.list();
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			session.close();
		}
		return list;
	}
}
