package ui;

import java.util.List;

import resources.AppConfig;
import resources.HibernateUtility;
import bean.Employee;
import dao.EmployeeDepartmentDAO;

public class UserInterface {

	public static void projectionsProperty() {
		List<Employee> empDetails = null;
		try {
			EmployeeDepartmentDAO dao = new EmployeeDepartmentDAO();
			empDetails = dao.projectionsProperty();
			System.out.println("List of Employees ");
			System.out.println("==================");
			System.out.println("Employee Id\t\tName");
			System.out.println("======================================");
			for (Employee employee : empDetails) {
				System.out.println(employee.getEmpId() + "\t\t\t"
						+ employee.getName() + "\t\t\t");
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	public static void associations() {
		List<Employee> empDetails = null;
		try {
			EmployeeDepartmentDAO dao = new EmployeeDepartmentDAO();
			empDetails = dao.associations();
			System.out.println("List of Employees ");
			System.out.println("==================");
			System.out.println("Employee Id\tName\tDepartment Code\tDepartment Name");
			System.out.println("==========================================================");
			for (Employee employee : empDetails) {
			System.out.println(employee.getEmpId()+"\t\t"+employee.getName()+"\t\t"+employee.getDepartment().getDeptCode()+"\t\t"+employee.getDepartment().getDeptName()+"\t\t");
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	public static void projectionsAggregate() {
		List<Object[]> list = null;
		try {
			EmployeeDepartmentDAO dao = new EmployeeDepartmentDAO();
			list = dao.projectionsAggregate();
			Object[] obj=list.get(0);
			System.out.println("The maximum of employee id:"+obj[0]);
			System.out.println("The minimum of employee id:"+obj[1]);
			System.out.println("The average of employee ids:"+obj[2]);
			System.out.println("The count of employee ids:"+obj[3]);
			System.out.println("The sum of employee ids:"+obj[4]);
			System.out.println("The distinct count of employee ids:"+obj[5]);
			System.out.println("The row count is:"+obj[6]);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	
	public static void main(String args[]) {
		try {
		//projectionsProperty();
		//projectionsAggregate();
		associations();
		}finally{
			HibernateUtility.closeSessionFactory();
		}
	}
}
