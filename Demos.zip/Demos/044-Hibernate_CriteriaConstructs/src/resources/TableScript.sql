DROP TABLE Employee CASCADE CONSTRAINTS;
DROP TABLE Department CASCADE CONSTRAINTS;

CREATE TABLE Employee(EmpId number(7),
Name varchar2(25) CONSTRAINT ENameNnull NOT NULL,
DeptCode number(4) );

CREATE TABLE Department(DeptCode number(4),
DeptName Varchar2(20) CONSTRAINT DNameNnull NOT NULL
);

INSERT INTO Employee VALUES(1001,'Scott',10);
INSERT INTO Employee VALUES(1002,'Jack',10);
INSERT INTO Employee VALUES(1003,'Ram',20);
INSERT INTO Employee VALUES(1004,'Sita',20);
INSERT INTO Employee VALUES(1004,'Sita',20);
INSERT INTO Employee VALUES(1004,'Sita',20);
COMMIT;

INSERT INTO Department VALUES(10,'JEE');
INSERT INTO Department VALUES(20,'MS');
INSERT INTO Department VALUES(30,'Mobility');
COMMIT; 

SELECT * FROM Employee;

SELECT * FROM Department;


