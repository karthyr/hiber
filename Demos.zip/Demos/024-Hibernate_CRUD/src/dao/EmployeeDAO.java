package dao;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Employee;
import entity.EmployeeEntity;

public class EmployeeDAO{
	/**
	 * Inserts a new employee into the database
	 * 
	 * @param employeeTO- employee details
	 * @throws Exception
	 */
	public void addEmployee(Employee employee)throws Exception {
		SessionFactory sessionFactory=HibernateUtility.createSessionFactory();
		Session session=null;
		
		try {
			
			session=sessionFactory.openSession();
						
			EmployeeEntity empEntity=new EmployeeEntity();
			empEntity.setEmployeeId(employee.getEmployeeId());
			empEntity.setEmployeeName(employee.getEmployeeName());
			empEntity.setBasicSalary(employee.getBasicSalary());
			empEntity.setAllowances(employee.getAllowances());
	
			session.beginTransaction();
			session.persist(empEntity);
			session.getTransaction().commit();
		}
		catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception); 
			throw new Exception("DAO.TECHNICAL_ERROR");
		} 
		catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
	}
	/**
	 * Update the allowances for the accepted empId in the database
	 * 
	 * @param employeeId
	 * @Param allowances
	 * @throws Exception 
	 */
	public void updateEmployeeAllowances(Integer employeeId, Double allowances) throws Exception {
		SessionFactory sessionFactory=HibernateUtility.createSessionFactory();
		Session session=null;
		
		try {
			
			session=sessionFactory.openSession();
			EmployeeEntity empEntity = (EmployeeEntity) session.get(EmployeeEntity.class,employeeId);
			
			session.getTransaction().begin();
			empEntity.setAllowances(allowances);
			session.getTransaction().commit();
		}
		catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception); 
			throw new Exception("DAO.TECHNICAL_ERROR");
		} 
		catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
	}
	
	/**
	 * Deletes the employee details from the database
	 * 
	 * @param empId- employeeId
	 * @throws Exception
	 * @author ETA
	 */
	public void deleteEmployee(Integer employeeId) throws Exception {
		SessionFactory sessionFactory=HibernateUtility.createSessionFactory();
		Session session=null;
		
		try {
			
			session=sessionFactory.openSession();
			EmployeeEntity empEntity = (EmployeeEntity) session.get(EmployeeEntity.class,employeeId);
			
			session.beginTransaction();
			session.delete(empEntity);
			session.getTransaction().commit();
		}
		catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception); 
			throw new Exception("DAO.TECHNICAL_ERROR");
		} 
		catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		}
		finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
	}
	/**
	 * Retrieves the details of employee from the database 
	 * 
	 * @param employeeId
	 * @return Employee
	 * @throws Exception
	 */
	public Employee getEmployeeDetails(Integer employeeId) throws Exception {

		Employee employee = null;
		EmployeeEntity employeeEntity = null;
		
		SessionFactory sessionFactory=HibernateUtility.createSessionFactory();
		Session session=null;
		
		try {
			
			session=sessionFactory.openSession();

			employeeEntity = (EmployeeEntity) session.get(EmployeeEntity.class, employeeId);
			
			employee=new Employee();
			employee.setEmployeeId(employeeEntity.getEmployeeId());
			employee.setEmployeeName(employeeEntity.getEmployeeName());
			employee.setBasicSalary(employeeEntity.getBasicSalary());
			employee.setAllowances(employeeEntity.getAllowances());
			

		} catch (HibernateException exception) {
			
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return employee;
	}
}
