package ui;

import resources.AppConfig;
import resources.HibernateUtility;
import bean.Employee;
import dao.EmployeeDAO;

public class UserInterface {

	public static void addEmployee() {
		try {
			Employee employee = new Employee();

			employee.setEmployeeId(1005);
			employee.setEmployeeName("Clark");
			employee.setBasicSalary(10600.00);
			employee.setAllowances(12000.00);

			EmployeeDAO dao = new EmployeeDAO();
			dao.addEmployee(employee);

			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.NEW_EMPLOYEE_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateEmployeeAllowances() {
		try {
			Integer empId = 1005;
			Double allowances = 15000.00;

			EmployeeDAO dao = new EmployeeDAO();
			dao.updateEmployeeAllowances(empId, allowances);

			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.EMPLOYEE_ALLOWANCES_UPDATE_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteEmployee() {
		try {
			Integer empId = 1005;

			EmployeeDAO dao = new EmployeeDAO();
			dao.deleteEmployee(empId);

			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.EMPLOYEE_DELETE_SUCCESS");
			System.out.println(message);
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getEmployeeDetails() {
		try {

			EmployeeDAO dao = new EmployeeDAO();
			Employee employee = dao.getEmployeeDetails(1005);

			System.out.println("*******Employee Details********");
			System.out.println("Employee Id:		" + employee.getEmployeeId());
			System.out.println("Employee Name:		" + employee.getEmployeeName());
			System.out.println("Employee Allowance:	"
					+ employee.getAllowances());
			System.out.println("Basic Salary:		" + employee.getBasicSalary());

		} catch (Exception e) {

			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
		System.out.println("\n\n");
	}

	public static void main(String args[]) {

		try {
			// addEmployee();
			// getEmployeeDetails();
			// updateEmployeeAllowances();
			// deleteEmployee();
		} finally {
			HibernateUtility.closeSessionFactory();
		}

	}
}
