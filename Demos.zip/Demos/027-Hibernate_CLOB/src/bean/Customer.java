package bean;

/**
 * Bean class
 * 
 * @author ETA
 *
 */
public class Customer {

	private Integer customerId;
	private String customerName;
	private String customerDocs;

	public String getCustomerDocs() {
		return customerDocs;
	}

	public void setCustomerDocs(String customerDocs) {
		this.customerDocs = customerDocs;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

}
