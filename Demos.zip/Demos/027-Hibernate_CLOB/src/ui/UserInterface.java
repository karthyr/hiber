package ui;

import dao.CustomerDAO;
import bean.Customer;
import resources.HibernateUtility;


public class UserInterface {

	public static void main(String[] args) {
	
		try{
		//	addCustomer();
		//	getCustomerDetails();
		}finally{
			HibernateUtility.closeSessionFactory();
		}
		
	}

	public static void getCustomerDetails() {
		try {
			Integer customerId=1001;
			Customer customer=new CustomerDAO().getCustomerDetails(customerId);
			System.out.println("-----------------------------------------------");
			System.out.println("Customer Id : "+customer.getCustomerId());
			System.out.println("Customer Name: "+customer.getCustomerName());
			System.out.println("Customer Details :"+customer.getCustomerDocs());
			System.out.println("-----------------------------------------------");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public static void addCustomer() {
		try {
			Customer customer=new Customer();
			customer.setCustomerId(1001);
			customer.setCustomerName("Gavin");
			String customerDocssString = "\nHi this is customer details.\n It holds important informations e.g. ,"
					+ "location,choices and likes, date of birth \n and most importantly "
					+ "offer details and services requested. This document is important \nand should be stored along with other"
					+ " details of customer.";
			customer.setCustomerDocs(customerDocssString);
			
			Integer customerId=new CustomerDAO().addCustomer(customer);
			System.out.println("Customer registered successfully with customerId :" +customerId);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
}
