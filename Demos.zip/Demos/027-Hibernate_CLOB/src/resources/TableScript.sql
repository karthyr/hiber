DROP TABLE Customer CASCADE CONSTRAINTS;

CREATE TABLE Customer(
customerid Number(5) CONSTRAINT cons_cust_Pkey PRIMARY KEY,
customername Varchar2(25) CONSTRAINT cons_cust_nnull NOT NULL,
customerDocs CLOB
);


SELECT * from Customer;