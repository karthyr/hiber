package dao;

import java.sql.Clob;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Customer;
import entity.CustomerEntity;

public class CustomerDAO {

	public Integer addCustomer(Customer customer) {
		Session session = null;
		Integer employeeId = null;
		try {

			SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			CustomerEntity entity = new CustomerEntity();
			entity.setCustomerId(customer.getCustomerId());
			entity.setCustomerName(customer.getCustomerName());
			String customerDocsString=customer.getCustomerDocs();
			
			Clob customerDetails = Hibernate.getLobCreator(session).createClob(customerDocsString);
			
			entity.setCustomerDocs(customerDetails);
			session.beginTransaction();

			employeeId = (Integer) session.save(entity);

			session.getTransaction().commit();
			customerDetails.free();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return employeeId;
	}

	public Customer getCustomerDetails(Integer customerId) {
		Session session = null;
		Customer customer = null;
		
		try{
			SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			CustomerEntity entity = (CustomerEntity) session.get(CustomerEntity.class, customerId);

			customer = new Customer();
			customer.setCustomerId(entity.getCustomerId());
			customer.setCustomerName(entity.getCustomerName());

			Clob data=entity.getCustomerDocs();
			String dataString=data.getSubString(1, (int) data.length());
			customer.setCustomerDocs(dataString);
			
			data.free();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return customer;
	}

}
