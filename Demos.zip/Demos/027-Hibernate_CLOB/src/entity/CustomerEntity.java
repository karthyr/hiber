package entity;

import java.sql.Clob;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * Customer Entity Class
 * 
 * @author ETA
 *
 */
@Entity
@Table(name = "customer")
public class CustomerEntity {

	@Id
	private Integer customerId;
	private String customerName;
	@Lob// Optional
	private Clob customerDocs;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Clob getCustomerDocs() {
		return customerDocs;
	}

	public void setCustomerDocs(Clob customerDocs) {
		this.customerDocs = customerDocs;
	}

}
