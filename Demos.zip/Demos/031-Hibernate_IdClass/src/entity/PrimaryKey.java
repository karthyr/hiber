package entity;

import java.io.Serializable;

/* The Id class must implement Serializable interface. Serialization is
 * technique used to pass Java objects through a secure medium to file system or database 
 */
public class PrimaryKey implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String certificationCode;
	private Integer empId;

	public String getCertificationCode() {
		return certificationCode;
	}

	public void setCertificationCode(String certificationCode) {
		this.certificationCode = certificationCode;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
}
