package ui;

import resources.AppConfig;
import resources.HibernateUtility;
import bean.EmployeeCertification;
import dao.EmployeeCertificationDAO;



public class UserInterface {
	
	public static void addEmployeeCertification() {
		try {
			EmployeeCertification employeeCertification = new EmployeeCertification();
			employeeCertification.setEmpId(1002);
			employeeCertification.setCertificationCode("JAVA-101");
			employeeCertification.setMarks(82);
			
			EmployeeCertificationDAO dao = new EmployeeCertificationDAO();
			dao.addEmployeeCertification(employeeCertification);
			String message = AppConfig.PROPERTIES.getProperty("UserInterface.EMPLOYEE_CERTIFICATION_SUCCESS");
			System.out.println(message);
		}
		catch (Exception e) {
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	
	public static void getEmployeeCertificationDetails() {
		try {
			EmployeeCertificationDAO dao = new EmployeeCertificationDAO();
			EmployeeCertification employeeCertification=dao.getEmployeeCertificationDetails(1002,"Java-101");
			System.out.println("------------------EMPLOYEE CERTIFICATION DETAILS------------------------------");
			System.out.println("Employee Name 	   : "+employeeCertification.getEmployeeName());
			System.out.println("Certification Name : "+employeeCertification.getCertificationName());
			System.out.println("Certification Type : "+employeeCertification.getCertificationType());
			System.out.println("Marks	           : "+employeeCertification.getMarks());
			System.out.println("-------------------------------------------------------------------------------");
		}
		catch (Exception e) {
			
			System.out.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}
	
	public static void main(String args[]){
		try {
				//addEmployeeCertification();
				getEmployeeCertificationDetails();
		}finally{
			HibernateUtility.closeSessionFactory();
		}
	}
}
