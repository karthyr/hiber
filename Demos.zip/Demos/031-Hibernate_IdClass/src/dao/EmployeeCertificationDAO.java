package dao;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.EmployeeCertification;
import entity.CertificationEntity;
import entity.EmployeeCertificationEntity;
import entity.EmployeeEntity;
import entity.PrimaryKey;

public class EmployeeCertificationDAO {

	/**
	 * Inserts the employee certification details into the database
	 * 
	 * @param EmployeeCertification
	 *            - employee certification details
	 * @throws Exception
	 *             If there is a technical error
	 */
	public void addEmployeeCertification(EmployeeCertification employeeCertification) throws Exception {
		
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session=null;
		try {
			session = sessionFactory.openSession();
			

			EmployeeEntity employeeEntity=(EmployeeEntity) session.get(EmployeeEntity.class, employeeCertification.getEmpId()) ;
			 
			CertificationEntity certificationEntity=(CertificationEntity) session.get(CertificationEntity.class,employeeCertification.getCertificationCode().toUpperCase());
			// Verifying existence of employee and certification details in corresponding database tables
			if(employeeEntity!=null && certificationEntity!=null){
			EmployeeCertificationEntity employeeCertEntity = new EmployeeCertificationEntity();
			employeeCertEntity.setEmpId(employeeCertification.getEmpId());
			employeeCertEntity.setCertificationCode(employeeCertification.getCertificationCode().toUpperCase());
			
			employeeCertEntity.setMarks(employeeCertification.getMarks());

			session.getTransaction().begin();
			session.persist(employeeCertEntity);
			session.getTransaction().commit();
			}
		} catch (HibernateException exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen() || session!=null){
				session.close();
			}
		}
	}

	/**
	 * Fetches the certification details for the accepted employeeId and
	 * certificationCode from the database
	 * 
	 * @param emloyeeId
	 * @param certificationCode
	 * @return EmployeeCertification
	 * @throws Exception
	 *             if there is a technical error
	 */
	public EmployeeCertification getEmployeeCertificationDetails(Integer empId,String certificationCode) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		EmployeeCertification employeeCertification = null;
		Session session = null;
		try {
			 session = sessionFactory.openSession();
			
			
			EmployeeEntity employeeEntity=(EmployeeEntity) session.get(EmployeeEntity.class, empId) ;
			 
			CertificationEntity certificationEntity=(CertificationEntity) session.get(CertificationEntity.class, certificationCode.toUpperCase());
			
			PrimaryKey primaryKey=null;
			// Checking the existence of id values in corresponding tables
			if(employeeEntity!=null && certificationEntity!=null){
				primaryKey = new PrimaryKey();
				primaryKey.setCertificationCode(certificationCode.toUpperCase());
				primaryKey.setEmpId(empId);
			}
			
			EmployeeCertificationEntity empCertEntity = (EmployeeCertificationEntity) session.get(EmployeeCertificationEntity.class, primaryKey);
			
			if (empCertEntity != null) {
				employeeCertification = new EmployeeCertification();
				employeeCertification.setMarks(empCertEntity.getMarks());
				
				employeeCertification.setEmpId(empId);
				employeeCertification.setCertificationCode(certificationCode);
				employeeCertification.setEmployeeName(employeeEntity.getName());
				employeeCertification.setCertificationName(certificationEntity.getCertificationName());
				employeeCertification.setCertificationType(certificationEntity.getCertificationType());
			}
			
		} catch (HibernateException exception) {
		
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} catch (Exception exception) {
		
			DOMConfigurator.configure("src/resources/log4j.xml");
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw exception;
		} finally {
			if(session.isOpen() || session!=null){
				session.close();
			}
		}
		return employeeCertification;
	}
}
