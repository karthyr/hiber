package bean;

import java.io.Serializable;
import java.util.Calendar;

/**
 * Bean class to hold the employee data
 * private data members
 * public getters and setters
 * @author ETA
 */


public class Employee implements Serializable { // implements Serializable

	private static final long serialVersionUID = 1L;

	private String employeeName;
	private Calendar dateOfBirth;
	private String phoneNumber;
	private String password;

	
	public Calendar getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Calendar dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
}
