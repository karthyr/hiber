package demo;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Calendar;

import bean.Employee;

public class ObjectOutputStreamTester {

	public static void main(String[] args) {
		try 
		
			(
			FileOutputStream fos = new FileOutputStream("resources/EmployeeDetails.dat");//specify the file name into which the data is to be written
			ObjectOutputStream oos = new ObjectOutputStream(fos) // stream chaining
			) { 
			
			//Creating and populating the object 
			Employee emp = new Employee();
			emp.setEmployeeName("eta@infy.com");
			emp.setPhoneNumber("9876543210");
			Calendar dob = Calendar.getInstance();
			dob.set(1985, 2, 1);
			emp.setDateOfBirth(dob);
			
			// writing the object
			oos.writeObject(emp);
			
			System.out.println("Object written to file successfully");
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		}

	}

}
