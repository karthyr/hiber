package demo;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import bean.Employee;

public class ObjectInputStreamTester {

	public static void main(String[] args) {
		try 
			(
			FileInputStream fis = new FileInputStream("resources/EmployeeDetails.dat"); //specify the file name from which the data is to be read
			ObjectInputStream ois = new ObjectInputStream(fis)  // stream chaining
			) 
		{
			
			
			// reading the object
			Employee emp = (Employee) ois.readObject();
			
			System.out.println("Object read successfully");
			System.out.println("-----------------------------------------");
			//display the details in the console
			System.out.println("User name : "+emp.getEmployeeName());
			System.out.println("Phone number : "+emp.getPhoneNumber());
			System.out.println("Date of birth : "+emp.getDateOfBirth().getTime());
			System.out.println("-----------------------------------------");
		} 
		
		catch (IOException ioe) {
			System.err.println("ERROR: "+ioe.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.err.println("ERROR: "+cnfe.getMessage());
		}

	}

}
