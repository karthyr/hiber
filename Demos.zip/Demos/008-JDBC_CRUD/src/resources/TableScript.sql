Drop table customer cascade constraints;

create table customer (
customerid number(6) CONSTRAINT cust_pk primary key,
customername VARCHAR2(25),
dateofbirth date
);

insert into customer values(1001,'Scott','22-JAN-1989');
insert into customer values(1002,'Gary','13-JUN-1991');
insert into customer values(1003,'Robert','10-APR-1975');

select * from customer;