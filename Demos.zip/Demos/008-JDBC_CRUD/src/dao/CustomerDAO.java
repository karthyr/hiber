package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import bean.Customer;



public class CustomerDAO {
	
	public Integer addCustomer(Customer customer)throws Exception{
		int count=0;
		
		// sql statement
		String sql="insert into customer values(?,?,?)";
			
		// try-with-resources : Creating Connection and PreparedStatment instance
		try (Connection connection=DriverManager.getConnection("jdbc:oracle:thin:system/oracle@localhost:1521:xe");
			PreparedStatement pStatement=connection.prepareStatement(sql)
			){
			
			// Setting the parameters for the statement
			pStatement.setInt(1, customer.getCustomerId());
			pStatement.setString(2, customer.getCustomerName());
			pStatement.setDate(3, new Date(customer.getDateOfBirth().getTimeInMillis()));
			
			// Executing the statement
			count=pStatement.executeUpdate();
				
		} catch (SQLException exception) {
			throw new Exception("DAO.TECHNICAL_ERROR");
		}
		catch (Exception exception) {
			throw exception;
		}
		return count;
	}
	
	public Customer getCustomerDetails(Integer customerId)throws Exception{
		Customer customer=null;
		
		// sql statement
		String sql="select * from customer where customerId=?";
				
		// try-with-resources : Creating Connection and PreparedStatment instance
		try (Connection connection=DriverManager.getConnection("jdbc:oracle:thin:system/oracle@localhost:1521:xe");
				PreparedStatement pStatement=connection.prepareStatement(sql)
				){
		    pStatement.setInt(1, customerId);
			
			ResultSet resultSet=pStatement.executeQuery();
			resultSet.next();			
			
			Integer id=resultSet.getInt(1);
			String customerName=resultSet.getString("customerName");
			Date dob=resultSet.getDate("dateOfBirth");
			Calendar cal=Calendar.getInstance();
			cal.setTime(dob);
			
			customer=new Customer();
			customer.setCustomerId(id);
			customer.setCustomerName(customerName);
			customer.setDateOfBirth(cal);
			
		} catch (SQLException exception) {
			throw new Exception("DAO.TECHNICAL_ERROR");
		}
		catch (Exception exception) {
			throw exception;
		}

		return customer;
	}

	public void deleteCustomer(Integer customerId) throws Exception {
		
		// sql statement
		String sql="delete  from customer where customerId=?";
				
		// try-with-resources : Creating Connection and PreparedStatment instance
		try (Connection connection=DriverManager.getConnection("jdbc:oracle:thin:system/oracle@localhost:1521:xe");
				PreparedStatement pStatement=connection.prepareStatement(sql)
				){
			pStatement.setInt(1, customerId);
			
			pStatement.executeUpdate();
					
		} catch (SQLException exception) {
			throw new Exception("DAO.TECHNICAL_ERROR");
		}
		catch (Exception exception) {
			throw exception;
		}
	}

	public void updateCustomer(Customer customer)throws Exception {
		
		// sql statement
		String sql="update customer set customername= ? where customerid=?";
		
		// try-with-resources : Creating Connection and PreparedStatment instance
		try (Connection connection=DriverManager.getConnection("jdbc:oracle:thin:system/oracle@localhost:1521:xe");
				PreparedStatement pStatement=connection.prepareStatement(sql)
				){
		    	pStatement.setString(1, customer.getCustomerName());
		    	pStatement.setInt(2, customer.getCustomerId());
			
			pStatement.executeUpdate();
					
		} catch (SQLException exception) {
			throw new Exception("DAO.TECHNICAL_ERROR");
		}
		catch (Exception exception) {
			throw exception;
		}
	}

	
}
