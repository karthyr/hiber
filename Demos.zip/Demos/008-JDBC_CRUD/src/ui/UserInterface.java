package ui;

import java.util.Calendar;

import resources.AppConfig;
import bean.Customer;
import dao.CustomerDAO;

public class UserInterface {

	public static void main(String args[]) {

		//addCustomer();
		//getCustomerDetails();
		//updateCustomer();
		deleteCustomer();
	}

	public static void addCustomer() {
		try {
			Customer customer = new Customer();
			customer.setCustomerId(1004);
			customer.setCustomerName("Jack");
			Calendar dateOfBirth=Calendar.getInstance();
			dateOfBirth.set(1991, 10, 11);
			customer.setDateOfBirth(dateOfBirth);

			int count = new CustomerDAO().addCustomer(customer);
			if (count == 1) {
				System.out.println(AppConfig.PROPERTIES.getProperty("UserInteface.INSERT_SUCCESS"));
			}
		} catch (Exception exception) {
			System.err.println("ERROR: "+AppConfig.PROPERTIES.getProperty(exception.getMessage()));
		}
	}

	public static void getCustomerDetails() {
		try {
			Integer customerId=1001;
			Customer customer = new CustomerDAO().getCustomerDetails(customerId);
			System.out.println("--------------------------------------------");
			System.out.println("Customer Id: "+customer.getCustomerId());
			System.out.println("Customer Name : "+customer.getCustomerName());
			Calendar dob=customer.getDateOfBirth();
			System.out.println("Date of birth : "+dob.get(Calendar.YEAR)+"-"+dob.get(Calendar.MONTH)+"-"+dob.get(Calendar.DATE));
			System.out.println("--------------------------------------------");
		} catch (Exception exception) {
			System.err.println("ERROR: "+AppConfig.PROPERTIES.getProperty(exception
					.getMessage()));
		}
	}
	
	public static void updateCustomer(){
		try {
			
			Customer customer = new Customer();
			customer.setCustomerId(1003);
			customer.setCustomerName("Tina");
			
			new CustomerDAO().updateCustomer(customer);
			
			System.out.println(AppConfig.PROPERTIES.getProperty("UserInteface.UPDATE_SUCCESS"));
		} catch (Exception exception) {
			System.err.println("ERROR: "+AppConfig.PROPERTIES.getProperty(exception
					.getMessage()));
		}
	}

	public static void deleteCustomer(){
		try {
			Integer customerId=1002;
				
			new CustomerDAO().deleteCustomer(customerId);
			System.out.println(AppConfig.PROPERTIES.getProperty("UserInteface.DELETE_SUCCESS"));
			
		} catch (Exception exception) {
			System.err.println("ERROR: "+AppConfig.PROPERTIES.getProperty(exception.getMessage()));
		}
	}
}
