package dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Blob;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resources.HibernateUtility;
import bean.Customer;
import entity.CustomerEntity;


public class CustomerDAO {

	public Integer addCustomer(Customer customer) {
		Session session = null;
		Integer employeeId = null;
		
		File file = new File("src/resources/gavin.jpg");
		
		try (FileInputStream fis=new FileInputStream(file);){
			
			SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			CustomerEntity entity = new CustomerEntity();
			entity.setCustomerId(customer.getCustomerId());
			entity.setCustomerName(customer.getCustomerName());
			
			Blob image=Hibernate.getLobCreator(session).createBlob(fis, file.length());
			entity.setCustomerImage(image);

			session.beginTransaction();

			employeeId = (Integer) session.save(entity);

			session.getTransaction().commit();

			image.free();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally{
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return employeeId;
	}
	
	public Customer getCustomerDetails(Integer customerId) {
		Session session=null;
		Customer customer=null;
		try(FileOutputStream fos=new FileOutputStream("output/customer"+customerId+".jpg")) {
			SessionFactory sessionFactory=HibernateUtility.createSessionFactory();
			session=sessionFactory.openSession();
			
			CustomerEntity entity = (CustomerEntity) session.get(CustomerEntity.class, customerId);
			
			customer=new Customer();
			customer.setCustomerId(entity.getCustomerId());
			customer.setCustomerName(entity.getCustomerName());
			
			Blob image=entity.getCustomerImage();
			byte[] data=image.getBytes(1, (int) image.length());
			fos.write(data);
			image.free();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally{
			if(session.isOpen()|| session!=null){
				session.close();
			}
		}
		return customer;
	}	

}
