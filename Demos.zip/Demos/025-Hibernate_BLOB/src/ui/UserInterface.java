package ui;

import dao.CustomerDAO;
import bean.Customer;
import resources.HibernateUtility;


public class UserInterface {

	public static void main(String[] args) {
	
		try{
			//addCustomer();
			getCustomerDetails();
		}finally{
			HibernateUtility.closeSessionFactory();
		}
		
	}

	public static void getCustomerDetails() {
		try {
			Integer customerId=1001;
			Customer customer=new CustomerDAO().getCustomerDetails(customerId);
			System.out.println("-----------------------------------------------");
			System.out.println("Customer Id : "+customer.getCustomerId());
			System.out.println("Customer Name: "+customer.getCustomerName());
			System.out.println("Customer Image : output/customer"+customer.getCustomerId()+".jpg");
			System.out.println("-----------------------------------------------");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public static void addCustomer() {
		try {
			Customer customer=new Customer();
			customer.setCustomerId(1001);
			customer.setCustomerName("Gavin");
			Integer customerId=new CustomerDAO().addCustomer(customer);
			System.out.println("Customer registered successfully with customerId :" +customerId);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
}
