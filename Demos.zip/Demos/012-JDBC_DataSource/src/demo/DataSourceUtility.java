
package demo;

import oracle.jdbc.pool.OracleDataSource;
import resources.AppConfig;

public class DataSourceUtility {

	public static OracleDataSource getOracleDataSource(String databaseType) throws Exception{
		OracleDataSource oracleDS = null;
		//Reading the values for DB_URL, USERNAME and PASSSWORD from the configuration.properties
		String DBConnectionURL = AppConfig.PROPERTIES.getProperty("ORACLE_DB_URL");
		String DBUserName = AppConfig.PROPERTIES.getProperty("ORACLE_DB_USERNAME");
		String DBPassword = AppConfig.PROPERTIES.getProperty("ORACLE_DB_PASSWORD");
		try 
		{
		if(databaseType.equalsIgnoreCase("oracle")){
				
		//creating and populating the OracleDataSource object with the required details
		oracleDS = new OracleDataSource();
		oracleDS.setURL(DBConnectionURL);
		oracleDS.setUser(DBUserName);
		oracleDS.setPassword(DBPassword);
			
		}else{
			throw new Exception("Given database type is Invalid");
			}
		
		}catch (Exception e){
				System.err.println("ERROR: "+e.getMessage());
			}
			return oracleDS;
		}
}

