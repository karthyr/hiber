package demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;
import resources.AppConfig;

public class DataSourceDemo {
	
	public static void main(String args[]) {
		try {
			String databaseType = "oracle";
			new DataSourceDemo().getCustomerDetails(databaseType);
		} catch (Exception exception) {
			System.err.println(AppConfig.PROPERTIES.getProperty(exception.getMessage()));
		}
	}

	public void getCustomerDetails(String dbType) throws Exception {

		OracleDataSource ds = null;
		ds = DataSourceUtility.getOracleDataSource(dbType);
		
		String sql = "select * from customer";
		ResultSet rs = null;

		// Using try with resources
		try (Connection connection = ds.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			
			rs = preparedStatement.executeQuery();
			System.out.println("Customer Details ");
			while (rs.next()) {
				System.out.println("-------------------------------");
				System.out.println("Customer ID: " + rs.getInt(1));
				System.out.println("Name 	: "+ rs.getString(2)); 
				System.out.println("EmaiLd 	: " + rs.getString(3));
				System.out.println("-------------------------------");
			}
		} catch (SQLException exception) {
			System.err.println("ERROR :"+exception.getMessage());
			throw exception;
		} catch (Exception exception) {
			System.err.println("ERROR :"+exception.getMessage());
			throw exception;
		}

	}

}
