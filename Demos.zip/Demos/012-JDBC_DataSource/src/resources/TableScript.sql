DROP TABLE customer cascade constraints;

CREATE TABLE customer
(customerId NUMBER(4),
customerName VARCHAR2(10),
email VARCHAR2(20));

INSERT INTO customer VALUES(1001,'JACK','jack123@infy.com');
INSERT INTO customer VALUES(1002,'JILL','jill123@infy.com');

select * from customer;
